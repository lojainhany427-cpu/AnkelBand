# AstronautCare — integrated research prototype

AstronautCare is an educational software prototype for visualizing simulated ESP32 readings, lower-limb movement, anatomy information and spaceflight research. It is **not a medical device** and does not diagnose, prescribe treatment, or control an FES stimulator.

## Included modules

- Flask backend with JSON ingestion, server-sent-event live stream, SQLite history and CSV export.
- Three.js interactive full-body stylized anatomy teaching model with separately selectable major organs and structures (brain, eyes, heart, lungs, liver, stomach, pancreas, spleen, kidneys, intestines, bladder, thyroid, adrenal glands, major vessels, respiratory/digestive structures, skeleton and muscle groups). Skin, skeleton, muscles and organs can be toggled independently. The supplied anatomical reference image remains a separate reference panel; it is not represented as a 3D model.
- Browser-based virtual sensor laboratory with Resting, Walking, High activity and Recovery scenarios; sends labelled simulated packets to the backend once per second. No physical ESP32 or sensors are needed for this demo.
- Virtual lower-leg wearable band with sensor pods; EMG activity changes the calf/band visual, ankle angle moves the foot, and pressure changes the sole overlay.
- Sensor dashboard, movement view, read-only FES status, organ information, NASA source retrieval and reports.
- Serial bridge script for a local serial stream.
- Basic automated backend tests.

## Run in VS Code (Windows)

1. Install Python 3.10 or newer. Open this folder in VS Code.
2. Open Terminal and run:
   ```powershell
   cd backend
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   py app.py
   ```
3. Open http://127.0.0.1:5000 in your browser. Three.js and Chart.js load from CDNs, so the browser needs internet access.
4. To test without Wokwi or physical hardware, open Home and click **Start virtual simulation** in the Virtual sensor laboratory. Choose Resting, Walking, High activity or Recovery. Click Stop to stop sending readings. These are invented demo signals, not real measurements. The separate server demo checkbox is an alternative generator.

## Run on macOS / Linux

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

## Test the backend

In a second terminal, activate the same virtual environment and run:

```bash
cd backend
python -m unittest test_app -v
```

Health endpoint: `http://127.0.0.1:5000/api/health`. Service configuration status (does not call paid services): `http://127.0.0.1:5000/api/services/status`.

## Wokwi connection

Simulation reference: https://wokwi.com/projects/480594323742296065

The serial bridge is in `simulation/bridge.py`. Its documented serial options require a serial stream exposed by a local Wokwi-for-VS-Code setup, or an ESP32 connected over USB. A hosted Wokwi browser simulation does **not** automatically expose a local serial port to this backend. Follow `simulation/README.md`; do not describe manual JSON paste or demo generator data as a live Wokwi connection.

## Configuration

- Optional `INGEST_TOKEN` environment variable protects `/api/ingest`; set the same token in the bridge with `--token`. Leave blank only for local testing.
- Optional `ANTHROPIC_API_KEY` enables server-side AI synthesis. Never put an API key in frontend JavaScript. Without it, the app shows organ facts and retrieved sources without claiming AI synthesis.
- `ASTRONAUTCARE_HOST` defaults to `127.0.0.1` (local-only). Do not expose the development server to the public internet.

## What was updated in this build

- Added a browser-only virtual sensor laboratory with four selectable scenarios and Start/Stop controls. It sends clearly-labelled demo packets to the existing ingestion API and therefore updates the dashboard, charts, history and movement view.
- Added a virtual wearable calf band and sensor pods to the 3D leg. The band responds visually to simulated EMG; the foot angle and sole pressure overlay respond to their corresponding channels.


- Added the supplied anatomical reference image to the Anatomy page as a separate, clearly-labelled reference panel.
- Improved backend database-directory handling and made the health endpoint verify that SQLite is responding.
- Made the demo toggle reject non-boolean request values.
- Added a backend test for demo-toggle validation.

## Important limitations

- The included full-body anatomy is a stylized procedural model made from separate 3D meshes, not a photorealistic or medically validated anatomical atlas. It shows major organs and selected structures, not every anatomical structure or microscopic detail. The wearable band is also a virtual illustration. A licensed, detailed glTF/GLB atlas with independently named meshes is still needed for high-fidelity anatomy.
- The six channels in the referenced simulation are scaled analog values; labels such as heart rate and SpO2 do not make them clinical-grade measurements.
- One ankle/EMG/pressure channel cannot determine both legs independently. The UI asks which side to visualize; that side selection is an assumption.
- The ankle display is visually limited to a safe display range; raw incoming values remain shown separately. This is a visualization choice, not a clinical range.
- NASA endpoints can change or be unavailable. The Research page shows retrieval errors and source links; network access is required. NASA retrieval is tested only when you run a search from your computer.
- The Wokwi ADC channels are arbitrary mapped values, not actual biomedical measurements. See `docs/scientific-validation.md` before describing any values as measurements.
- AI synthesis requires an Anthropic API key kept on the backend. Provider usage may cost money; the key is optional and no key is included in this project.
- Real sensors, a physical band, calibration, validation, and supervised FES hardware work are outside what software alone can complete. No stimulation control is implemented.


## Scientific validity review

Read `docs/scientific-validation.md` for the verified mapping and limitations of each simulated channel. The current Wokwi code maps six ADC readings to human-looking units; this does not make them physiological measurements.


## Space Band AI model (experimental)

The archived synthetic classifier is included in `backend/models/` with its training source, generated dataset, and metrics in `backend/model_training/`. Its guarded endpoint is `POST /api/band-ai-demo`; see `docs/ai-integration.md` for the exact schema and limitations. It requires all nine original model features and is deliberately separate from live Wokwi readings because the six Wokwi channels do not provide equivalent feature definitions. The endpoint does not issue medical advice, control FES, or trigger emergency calls.

Install backend dependencies from `backend/requirements.txt`. The serialized artifact requires the matching scikit-learn version specified there. The model was trained on synthetic data only; its reported metrics are not clinical or astronaut validation.


## Full-body anatomy update
- The Anatomy page now shows a full-body 3D teaching model rather than only a small organ cluster and lower-limb model.
- Major visible organs and selected anatomical structures have independent selectable meshes and educational information entries.
- Layer controls toggle skin, skeleton, muscles and organs; Reset view returns the camera; Show all restores all layers.
- This is still a stylized teaching model. For atlas-grade accuracy, replace it with a properly licensed detailed GLB/glTF model and map the mesh names to the organ registry.
