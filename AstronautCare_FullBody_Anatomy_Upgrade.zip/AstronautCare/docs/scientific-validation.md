# Scientific validity and sensor-mapping review

## Executive result

The current Wokwi program reads six 12-bit ADC channels and linearly maps each raw value (0–4095) into a human-looking range. The Wokwi project source is available at https://wokwi.com/projects/480594323742296065. This is a **software simulation of arbitrary analog inputs**, not a set of validated biomedical sensors. The dashboard must label these as simulated/display values. Do not describe them as medically accurate measurements or use them for health decisions.

## Verified directly from the current Wokwi `main.py`

| Output key | GPIO | Code mapping | Scientific status |
|---|---:|---|---|
| `heartRate` | 32 | 40–160 | Not a heart-rate sensor. A potentiometer/ADC channel cannot measure pulse without a suitable optical/electrical sensor and signal-processing pipeline.
| `spo2` | 33 | 85–100 | Not an SpO₂ sensor. Requires an appropriate pulse-oximeter optical sensor, calibration, and validated algorithm.
| `temperature` | 34 | 34–40 °C | Not a temperature sensor. Requires a temperature transducer and calibration.
| `emg` | 35 | 0–100 arbitrary scale | Not EMG in physical units. Surface EMG needs an appropriate biopotential front-end, electrode configuration, filtering, sampling, and normalization protocol.
| `ankleAngle` | 25 | −90–90 degrees | Not an angle sensor. Requires a calibrated IMU/encoder or validated motion-capture reference and a defined anatomical coordinate convention.
| `footPressure` | 26 | 0–100 arbitrary scale | Not pressure in physical units. Requires calibrated force/pressure sensors, known area/geometry, and a defined unit such as kPa or N.
| `fesEnabled` | 18 | LOW means virtual ON | Digital switch state only. It does not indicate that any stimulator exists or is operating. UI remains read-only.
| `redAlert` / `alerts` | LED 5 / computed | Threshold flags in code | Demonstration logic only; thresholds are not clinical cutoffs.

## Data-path review

- The Wokwi code emits a JSON object once per second using `print(json.dumps(packet))`.
- The packet uses `device: "AstronautCare"` and the six field names expected by `/api/ingest`.
- Backend accepted ranges match the Wokwi linear mappings: heart rate 40–160, SpO₂ 85–100, temperature 34–40, EMG 0–100, ankle angle −90–90, foot pressure 0–100. These are **input-validation bounds only**, not normal ranges.
- The serial bridge filters for `device == "AstronautCare"` and forwards JSON to `/api/ingest`.
- The browser Wokwi page does not automatically expose its serial stream to a local Python process. For live serial forwarding, Wokwi's VS Code integration documents `rfc2217ServerPort = 4000`; the simulator must be running and its tab visible. See https://docs.wokwi.com/vscode/project-config.

## Required scientific upgrades before making measurement claims

1. Replace arbitrary ADC knobs with appropriate sensor models (or retain them but call them simulated controls).
2. Record raw ADC values alongside converted values, including units and calibration metadata.
3. Document sensor model, sampling rate, filtering, placement protocol, calibration procedure, uncertainty, and reference instrument for every channel.
4. Validate against an accepted reference method across repeated trials and report error metrics.
5. Separate engineering thresholds from clinical thresholds; do not label demo thresholds as normal/abnormal.
6. Keep AI outputs educational and source-grounded. No diagnosis, treatment, or FES activation.

## Safe wording for the project

Use: “simulated heart-rate-like value”, “simulated oxygen-saturation-like value”, “temperature input simulation”, “EMG activity index (arbitrary units)”, “simulated ankle angle”, and “plantar pressure index (arbitrary units)”. State clearly that the present Wokwi inputs are potentiometer-style analog controls unless the circuit diagram and sensor models prove otherwise.
