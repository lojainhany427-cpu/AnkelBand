# Space Band AI integration boundary

The archived Space Band model expects exactly these nine fields: `hr`, `spo2`, `skin_temp`, `emg_rms`, `emg_median_freq`, `ankle_rom`, `ankle_velocity`, `foot_pressure`, and `days_in_orbit`.

The current Wokwi/AstronautCare feed provides only six differently defined channels: `heartRate`, `spo2`, `temperature`, `emg`, `ankleAngle`, and `footPressure`. The temperature channel is an ADC-derived display value, EMG is an arbitrary activity index, ankleAngle is an instantaneous angle, and footPressure is an arbitrary index. The feed does not contain EMG median frequency, ankle velocity, or mission duration. These values must not be fabricated or silently relabelled.

## Endpoint

`POST /api/band-ai-demo` accepts a complete nine-feature JSON object. It validates every field and rejects missing/invalid values. This endpoint is for controlled synthetic demonstrations only; it is not called automatically from live telemetry.

The response contains a class label, model confidence, class probabilities, and a disclaimer. It deliberately omits the archived recommender's FES levels, stimulation instructions, treatment suggestions, and automatic Earth-call behavior.

## Runtime compatibility

The serialized model reports scikit-learn 1.9.1 as its training version. Install the exact version listed in `backend/requirements.txt`. If the runtime reports an inconsistent-version warning, the adapter marks the model unavailable instead of silently using an unverified artifact.

## Interpretation

The training dataset is synthetic. Reported accuracy and F1 are internal synthetic holdout metrics only. They are not clinical performance, astronaut validation, or evidence that the model detects medical conditions.
