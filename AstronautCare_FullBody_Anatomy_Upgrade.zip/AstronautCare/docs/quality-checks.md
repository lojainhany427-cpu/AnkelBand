# Quality checks

Run backend tests from `backend/` with `python -m unittest test_app -v`.

Manual acceptance checks:
1. Open `/api/health` and confirm `ok: true`.
2. Start the app and enable demo data. Confirm the status says Demo generator.
3. Open Movement and confirm the ankle/sole/muscle visualization responds to changing demo readings.
4. Disable demo data and wait for stale-data status.
5. Export CSV from Reports.
6. Only after a local serial bridge is available, test Wokwi packets and confirm the source label says Wokwi simulation.

Passing backend unit tests does not prove WebGL, external NASA APIs, AI credentials, Wokwi serial transport, or physical hardware operation.
