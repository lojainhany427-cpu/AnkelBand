# AstronautCare verification status (2026-11-14)

## Completed in this code update

- Added an `/api/services/status` endpoint. It reports whether the Anthropic key is configured without returning the key.
- Hardened NASA NTRS / OSDR parsing, bounded request timeouts, deduplicated source URLs, and returned clear error summaries rather than fabricated records.
- Improved the AI service's no-key fallback and response parsing. Model remains configurable with `ANTHROPIC_MODEL`; default is `claude-sonnet-5-5` (see Anthropic's model index).
- Improved the Wokwi serial bridge with a backend health preflight, optional token header, accepted-packet counter, and clearer failure messages.
- Added scientific validation notes for all six ADC-mapped channels and the virtual FES switch.
- Added offline unit tests for NASA response parsing and AI fallback/success response handling.

## Checks actually run in the build environment

| Check | Result | Evidence / limitation |
|---|---|---|
| Python syntax compilation | PASS | `py_compile` passed for backend and serial bridge files. |
| JavaScript syntax | PASS | `node --check` passed for `app.js` and `body.js`. |
| Offline NASA parser tests | PASS | NTRS and OSDR response-shape fixtures passed. These are mocked fixtures, not live NASA requests. |
| Offline AI tests | PASS | No-key fallback and mocked successful Anthropic response passed. No live provider request was made. |
| Existing Flask API tests | BLOCKED | Flask is not installed in this build environment. Run `pip install -r requirements.txt`, then `python -m unittest test_app -v` on your computer. |
| Live NASA API request | BLOCKED HERE | The build environment has no outbound DNS/network access. Run a query from the Research page on your laptop. |
| Live Anthropic API request | NOT RUN | Requires a valid private API key and may incur usage charges. Never paste the key into chat or frontend code. |
| Live Wokwi serial -> backend | NOT RUN | Requires your Wokwi VS Code simulator exposing RFC2217 port 4000 while the backend is running. |

## Your local end-to-end checks

1. Install dependencies and run backend tests: `pip install -r requirements.txt`, then `python -m unittest test_app test_services -v`.
2. Start the backend and open `http://127.0.0.1:5000/api/services/status`.
3. Open the Research page and search `spaceflight muscle` or `spaceflight bone loss`. Confirm that each result opens a NASA source record. If the page shows retrieval errors, save the exact error text.
4. For AI, configure `ANTHROPIC_API_KEY` in your local terminal environment (not in JavaScript or a committed file), restart the backend, and run one organ analysis. A key may incur charges; use it only with parent/guardian approval and never share it.
5. For Wokwi, run the project in Wokwi for VS Code with `rfc2217ServerPort = 4000` in `wokwi.toml`, keep the simulator tab visible, start the backend, then run `python simulation/bridge.py --serial rfc2217://localhost:4000`. Watch for `packet N: accepted (200)` and check the dashboard/history.

## Evidence boundaries

A successful mocked test verifies code behavior for a sample response, not that an external service is reachable. A valid JSON packet verifies transport format, not sensor accuracy. The current six analog channels are arbitrary mapped simulation inputs; do not present them as measured human physiology.

## Additional Space Band integration update (2026-11-14)

- Added the serialized model artifact and a guarded `/api/band-ai-demo` endpoint. The endpoint requires all nine original features and rejects missing or out-of-range values. It does not infer missing channels from the six Wokwi values.
- Added a model-availability indicator to the AI page and `/api/services/status`.
- Removed the archived recommender's stimulation levels, stimulation instructions, treatment suggestions, and automatic Earth-call behavior from the integration path. The new endpoint returns only a synthetic model label and probabilities.
- Added three adapter contract tests; they passed. Seven total offline adapter/NASA/AI service tests passed.
- Model loading is intentionally blocked in this environment because the artifact was serialized with scikit-learn 1.9.1 while the available runtime is 1.8.0. The adapter detects the version warning and reports unavailable. Install the pinned requirements in a connected local environment before testing inference.
- Full Flask API suite remains blocked because Flask is not installed here and package installation failed due unavailable network/DNS. The API route is syntax-compiled but not runtime-tested in this environment.
