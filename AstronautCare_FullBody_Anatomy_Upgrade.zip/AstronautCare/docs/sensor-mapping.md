# Sensor / input mapping (verified against current Wokwi `main.py`)

Source: https://wokwi.com/projects/480594323742296065

The current MicroPython code configures six ESP32 ADC channels at 12-bit resolution and maps each raw ADC reading (0–4095) linearly into a display range. This is a **simulated input mapping**, not validated biomedical acquisition. The source code alone does not establish that physical biomedical sensors are connected.

| JSON field | GPIO | Raw input | Code mapping | Display unit |
|---|---:|---|---:|---|
| `heartRate` | 32 | ADC | 40–160 | bpm-like simulation only |
| `spo2` | 33 | ADC | 85–100 | %-like simulation only |
| `temperature` | 34 | ADC | 34–40 | °C-like simulation only |
| `emg` | 35 | ADC | 0–100 | arbitrary activity index |
| `ankleAngle` | 25 | ADC | −90–90 | degrees-like simulation only |
| `footPressure` | 26 | ADC | 0–100 | arbitrary pressure index |
| `fesEnabled` | 18 | digital input, pull-up; LOW = true | boolean | virtual switch state only |
| `redAlert` | computed; controls LED GPIO 5 | boolean | any demo threshold crossed | simulation flag |
| `alerts` | computed | list of strings | threshold labels | simulation flags only |

## Validation and interpretation

The backend accepts the same numerical bounds as the mapping code. These are transport validation limits, not physiological normal ranges or medical alarm thresholds. The six values are derived from arbitrary analog inputs and must remain labelled **SIMULATED**. No medical conclusions can be inferred from them.

Only one ankle, EMG and foot-pressure channel exists. The displayed leg side is a UI selection, not a measured laterality. Positive ankle values are drawn as dorsiflexion in the current visualization; the sign convention must be confirmed with a calibrated reference before any research claim.

See `scientific-validation.md` for channel-by-channel limitations and requirements for validated measurements.
