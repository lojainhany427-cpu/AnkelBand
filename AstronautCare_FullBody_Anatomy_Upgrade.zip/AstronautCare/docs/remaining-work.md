# AstronautCare — remaining work after the virtual simulator update

## Implemented in this software build
- Browser-based virtual sensor generator with Resting, Walking, High activity and Recovery scenarios.
- Start/Stop controls; readings are sent to `/api/ingest` once per second as `demo-generator` data.
- Virtual lower-leg band and sensor pods in the procedural Three.js model.
- EMG changes the calf/band appearance; ankle angle rotates the foot; foot pressure changes the sole overlay.
- Existing dashboard, charts, SSE stream, SQLite history and CSV export consume the new packets through the existing API.

## Still needs external assets, setup or verification
1. A detailed, properly licensed GLB/glTF anatomical atlas with independently named organs and a usable skeleton/rig. The upgraded full-body procedural model shows major organs and structures, but remains an educational illustration rather than medically accurate anatomy.
2. If the GLB is supplied, map its skeleton/bones and mesh names to the ankle and muscle animation controls; this cannot be completed reliably without inspecting that actual asset.
3. Install Python dependencies from `backend/requirements.txt`, run the app in VS Code, and test on the target laptop/browser. This environment did not install or launch the Flask app.
4. Verify NASA retrieval against current NASA endpoints with internet access; no source should be fabricated if the endpoint fails.
5. Add an AI provider key only if AI-generated synthesis is desired. Keep it in the backend `.env`, never in frontend code. Without a key, the fallback organ facts/sources are not AI.
6. Test the supplied Wokwi project’s actual packet format and serial bridge if Wokwi is to be used. Hosted Wokwi in a browser does not automatically stream to a local Flask server. The browser virtual lab works independently.
7. Validate every sensor mapping and threshold against a documented engineering specification before presenting readings as anything beyond simulation.

## Safety / scope
- All browser-lab values are simulated and not clinical measurements.
- FES remains read-only monitoring; there is no stimulator control or stimulation guidance.
- The app is an educational prototype, not a medical device or diagnostic tool.

## Integration work completed in this build pass (2026-11-14)
- Added the Space Band serialized model artifact under `backend/models/`.
- Added an isolated `/api/band-ai-demo` adapter with strict nine-feature validation. It does not infer missing features from the six live Wokwi channels.
- The adapter returns only a model class label, confidence, probabilities, and a synthetic-data disclaimer. It cannot control FES or trigger alerts/calls.
- Added model availability to `/api/services/status` and contract tests for missing, invalid, and out-of-range model inputs.
- Added model runtime dependencies to `backend/requirements.txt`.

## Still not verified / not completed
- The model artifact was serialized with scikit-learn 1.9.1. This environment has 1.8.0 and reports an `InconsistentVersionWarning`; the adapter intentionally marks the model unavailable until the matching runtime is installed. Reinstall dependencies from `backend/requirements.txt` in a clean environment and retest.
- The AI demo endpoint is not a clinical model and is not wired to the live six-channel feed because the semantics/features do not match.
- NASA NTRS/OSDR live network retrieval still requires an internet-enabled runtime test.
- Wokwi serial forwarding still requires an actual running Wokwi VS Code simulator and serial/RFC2217 test.
- 3D motion mapping can be unit-tested with browser automation, but real WebGL/device verification remains outstanding.
- No physical sensors or medical-grade validation are claimed.


## Full-body anatomy enhancement
- Replaced the earlier compact torso/leg teaching geometry with a full-body model including head, eyes, brain, neck structures, lungs, heart, digestive organs, kidneys, urinary structures, pelvic organs, arms, legs, bones and muscle groups.
- Added independent layer visibility controls and reset/show-all controls on the Anatomy page.
- Added organ registry entries for newly selectable structures so they can open educational information and NASA-source analysis where a matching entry exists.
- Visual geometry is illustrative; organ placement, proportions and details require review against a licensed anatomical atlas before scientific or clinical use.
