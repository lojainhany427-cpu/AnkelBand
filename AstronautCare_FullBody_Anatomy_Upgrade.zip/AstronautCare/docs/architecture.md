# Architecture
Wokwi ESP32 (serial JSON lines) -> `simulation/bridge.py` -> `POST /api/ingest` (validate, store in SQLite, fan out)
-> `GET /api/stream` (Server-Sent Events, 2 s heartbeat) -> browser (Chart.js + Three.js).

- Data source tags: `wokwi-simulation`, `demo-generator`, `real-hardware`. Shown everywhere and stored per row.
- Staleness: client compares server clock; no packet for >5 s shows "Connection lost" and the 3D model returns to neutral.
- AI: `/api/analyze` retrieves NTRS/OSDR records, then (only if `ANTHROPIC_API_KEY` is set on the server) asks the model to summarise using only those sources.
- Model is modular: `frontend/scripts/body.js` can be swapped for a glTF loader while keeping `setSensors / select / registry`.
- Scaling path: swap SQLite for Postgres by replacing `db()` in `backend/app.py`.
