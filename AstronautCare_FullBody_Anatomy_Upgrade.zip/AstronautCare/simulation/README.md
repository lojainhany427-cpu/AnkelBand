# Connecting the Wokwi simulation

The web page on wokwi.com cannot be read by other programs. Options:

1. **Wokwi for VS Code (recommended)**: create a VS Code project with the same `main.py` and `diagram.json` (export from the Wokwi project),
   add a MicroPython ESP32 firmware, copy `wokwi.toml.example` to `wokwi.toml`, start the simulation, then run:
   `python bridge.py --serial rfc2217://localhost:4000`
   (Needs a Wokwi account/licence for VS Code. I could not test this step.)
2. **Real ESP32 over USB**: flash the same `main.py`, then `python bridge.py --serial COM5 --source real-hardware`.
3. **Live pipe**: `your_serial_command | python bridge.py --stdin`.

Pasting JSON by hand is not a live connection and is not supported. For a quick UI check use "demo data" in the app (clearly labelled).


The bridge now checks `GET /api/health` before listening (use `--skip-health-check` only for special test pipes). It forwards only valid JSON packets whose `device` field is `AstronautCare`; successful packets are counted in the terminal. The live Wokwi browser project URL by itself is not a serial port. The VS Code simulator must expose RFC2217 on port 4000 as described in the official Wokwi docs: https://docs.wokwi.com/vscode/project-config.
