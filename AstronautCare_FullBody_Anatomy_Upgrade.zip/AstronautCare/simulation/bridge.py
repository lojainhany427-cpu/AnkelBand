"""Bridge: Wokwi ESP32 serial output (JSON lines) -> AstronautCare backend.

  python bridge.py --serial rfc2217://localhost:4000   # Wokwi for VS Code (wokwi.toml: rfc2217ServerPort = 4000)
  python bridge.py --serial COM5 --source real-hardware # real ESP32 over USB
  some_command | python bridge.py --stdin               # any live stream of the serial log
"""
import argparse, json, sys, time
import requests

ap = argparse.ArgumentParser()
g = ap.add_mutually_exclusive_group(required=True)
g.add_argument("--serial"); g.add_argument("--stdin", action="store_true")
ap.add_argument("--baud", type=int, default=115200)
ap.add_argument("--server", default="http://127.0.0.1:5000")
ap.add_argument("--source", default="wokwi-simulation", choices=["wokwi-simulation", "real-hardware"])
ap.add_argument("--token", default="")
ap.add_argument("--skip-health-check", action="store_true", help="Skip the backend /api/health preflight")
a = ap.parse_args()


def lines():
    if a.stdin:
        for l in sys.stdin:
            yield l
        return
    import serial
    while True:
        try:
            s = serial.serial_for_url(a.serial, baudrate=a.baud, timeout=2)
            print("connected to", a.serial)
            while True:
                raw = s.readline()
                if raw:
                    yield raw.decode("utf-8", "replace")
        except Exception as e:
            print("serial error:", e, "- retrying in 3s")
            time.sleep(3)


if not a.skip_health_check:
    try:
        health = requests.get(a.server.rstrip("/") + "/api/health", timeout=5)
        health.raise_for_status()
        print("backend health: OK", health.json())
    except requests.RequestException as e:
        print("backend health check failed:", e)
        print("Start AstronautCare backend first, then run the bridge again.")
        sys.exit(2)

received = 0
for line in lines():
    line = line.strip()
    if not line.startswith("{"):
        continue  # banner lines from main.py
    try:
        pkt = json.loads(line)
    except json.JSONDecodeError:
        print("skip bad JSON:", line[:80]); continue
    if pkt.get("device") != "AstronautCare":
        continue
    pkt["_source"] = a.source
    try:
        headers = {"X-Ingest-Token": a.token} if a.token else {}
        r = requests.post(a.server.rstrip("/") + "/api/ingest", json=pkt, headers=headers, timeout=5)
        if r.ok:
            received += 1
            print(f"packet {received}: accepted ({r.status_code})")
        else:
            print("backend rejected packet:", r.status_code, r.text.strip()[:160])
    except requests.RequestException as e:
        print("backend unreachable:", e)
