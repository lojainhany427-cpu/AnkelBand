// Interactive educational anatomy model. Stylised procedural geometry; not a clinical atlas.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const COLORS = { skin: 0xd9a58a, bone: 0xe8dcc0, muscle: 0xa94d45 };
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
function heat(t) { const c = new THREE.Color(); c.setHSL((1 - clamp(t, 0, 1)) * .66, .9, .5); return c; }

export class BodyViewer {
  constructor(el, { mode = 'anatomy', onSelect = () => {} } = {}) {
    this.el = el; this.mode = mode; this.onSelect = onSelect; this.active = false;
    this.registry = {}; this.pick = []; this.layerMeshes = { skin: [], skeleton: [], muscles: [], organs: [] }; this.legs = {}; this.leg = 'left'; this.selected = null;
    this.target = { ankle: 0, emg: 0, pressure: null }; this.cur = { ankle: 0, emg: 0 };
    this.scene = new THREE.Scene(); this.scene.background = new THREE.Color(0x080f20);
    this.camera = new THREE.PerspectiveCamera(35, 1, .05, 50);
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2)); this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    el.appendChild(this.renderer.domElement);
    this.scene.add(new THREE.HemisphereLight(0xd7eaff, 0x17213a, 1.55));
    const key = new THREE.DirectionalLight(0xffffff, 2.0); key.position.set(2, 3, 4); this.scene.add(key);
    const rim = new THREE.DirectionalLight(0x3bd8ee, .8); rim.position.set(-3, 1, -2); this.scene.add(rim);
    this.controls = new OrbitControls(this.camera, this.renderer.domElement); this.controls.enableDamping = true; this.controls.minDistance = 1.1; this.controls.maxDistance = 6;
    this.build(); this.resetView();
    this.ray = new THREE.Raycaster(); this.ptr = new THREE.Vector2();
    const cv = this.renderer.domElement; let down = null;
    cv.addEventListener('pointerdown', e => { down = { x: e.clientX, y: e.clientY, t: performance.now() }; });
    cv.addEventListener('pointerup', e => { if (down && Math.hypot(e.clientX-down.x,e.clientY-down.y)<6 && performance.now()-down.t<500) this.click(e); down=null; });
    new ResizeObserver(() => this.resize()).observe(el); this.resize(); this.loop = this.loop.bind(this); requestAnimationFrame(this.loop);
  }
  group(parent, name) { const g = new THREE.Group(); g.name = name; parent.add(g); return g; }
  material(color, opacity=1, emissive=0x000000) { return new THREE.MeshStandardMaterial({ color, roughness:.55, metalness:.02, transparent:opacity<1, opacity, depthWrite:opacity>=1, emissive }); }
  mesh(geo, color, { parent=this.organs, pos=[0,0,0], scale=[1,1,1], rot=[0,0,0], opacity=1, id=null, layer='organs', emissive=0x000000 }={}) {
    const m = new THREE.Mesh(geo, this.material(color, opacity, emissive)); m.position.set(...pos); m.scale.set(...scale); m.rotation.set(...rot); parent.add(m); m.userData.layer=layer; if(this.layerMeshes[layer]) this.layerMeshes[layer].push(m);
    if (id) { m.userData.id=id; (this.registry[id] ||= []).push(m); this.pick.push(m); }
    return m;
  }
  capsule(parent, a, b, radius, color, opts={}) {
    const A=new THREE.Vector3(...a), B=new THREE.Vector3(...b), d=B.clone().sub(A);
    const m=this.mesh(new THREE.CapsuleGeometry(radius, Math.max(.001,d.length()-radius*2), 6, 12),color,{parent,pos:A.clone().add(B).multiplyScalar(.5).toArray(),...opts});
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize()); return m;
  }
  ellipsoid(parent, id, pos, scale, color, layer='organs', opacity=1) { return this.mesh(new THREE.SphereGeometry(1,28,20),color,{parent,pos,scale,id,layer,opacity}); }
  build() {
    this.root=this.group(this.scene,'human-body');
    this.shell=this.group(this.root,'skin-layer'); this.skeleton=this.group(this.root,'skeleton-layer'); this.muscles=this.group(this.root,'muscle-layer'); this.organs=this.group(this.root,'organ-layer'); this.wearables=this.group(this.root,'wearable-layer');
    const skin=COLORS.skin, bone=COLORS.bone, muscle=COLORS.muscle;
    // Semi-transparent outer silhouette and head.
    this.ellipsoid(this.shell,null,[0,1.13,0],[.235,.43,.13],skin,'skin',.12);
    this.ellipsoid(this.shell,null,[0,1.76,0],[.105,.135,.105],skin,'skin',.13);
    // Skull, brain and eyes.
    this.ellipsoid(this.skeleton,'skull',[0,1.76,0],[.105,.13,.105],bone,'skeleton',.48);
    this.ellipsoid(this.organs,'brain',[0,1.78,.025],[.078,.082,.072],0xe99bb8);
    for(const x of [-1,1]) this.ellipsoid(this.organs,'eyes',[x*.038,1.79,.091],[.018,.015,.012],0x78c9e8);
    // Neck and thorax framework.
    this.capsule(this.skeleton,[0,1.53,0],[0,1.64,0],.035,bone,{layer:'skeleton',opacity:.8});
    this.capsule(this.organs,[0,1.48,.015],[0,1.62,.015],.018,0xd28b63,{id:'trachea'});
    this.capsule(this.organs,[.015,1.47,-.015],[.015,1.30,-.015],.012,0xd8b68c,{id:'esophagus'});
    this.ellipsoid(this.organs,'thyroid',[0,1.535,.045],[.045,.022,.022],0xc97983);
    this.mesh(new THREE.TorusGeometry(.12,.008,8,36),0xd4a17b,{parent:this.organs,pos:[0,1.245,.015],rot:[Math.PI/2,0,0],id:'diaphragm'});
    // Rib cage: individual curved arcs, selectable as skeletal structures.
    for(let i=0;i<6;i++) { const y=1.43-i*.045, r=.105-i*.006; const rib=this.mesh(new THREE.TorusGeometry(r,.008,8,32,Math.PI),bone,{parent:this.skeleton,pos:[0,y,0],rot:[0,0,Math.PI],layer:'skeleton',opacity:.82,id:'ribcage'}); rib.scale.set(1,.78,1); }
    this.capsule(this.skeleton,[0,1.48,-.025],[0,1.02,-.025],.014,bone,{id:'spine',layer:'skeleton',opacity:.9});
    // Lungs, heart, and major vessels.
    this.ellipsoid(this.organs,'lungs',[-.075,1.37,.035],[.062,.13,.055],0xd98591);
    this.ellipsoid(this.organs,'lungs',[.075,1.37,.035],[.062,.13,.055],0xd98591);
    this.ellipsoid(this.organs,'heart',[.012,1.34,.105],[.045,.06,.04],0xc9364d);
    this.capsule(this.organs,[.012,1.39,.12],[.012,1.47,.12],.012,0xc94b54,{id:'major-vessels'});
    // Abdomen: liver, stomach, pancreas, spleen, kidneys.
    this.ellipsoid(this.organs,'liver',[-.085,1.12,.045],[.105,.07,.055],0x873b32);
    this.ellipsoid(this.organs,'gallbladder',[-.035,1.075,.09],[.016,.032,.014],0x76a66b);
    this.ellipsoid(this.organs,'stomach',[.055,1.13,.055],[.052,.075,.045],0xe7a17e);
    this.ellipsoid(this.organs,'pancreas',[.005,1.055,.06],[.085,.018,.022],0xe8bd78);
    this.ellipsoid(this.organs,'spleen',[.125,1.12,.025],[.027,.055,.026],0x713d55);
    this.ellipsoid(this.organs,'kidneys',[-.105,1.00,-.005],[.032,.055,.03],0x9a4d52);
    this.ellipsoid(this.organs,'kidneys',[.105,1.00,-.005],[.032,.055,.03],0x9a4d52);
    this.ellipsoid(this.organs,'adrenal-glands',[-.105,1.065,.002],[.025,.012,.018],0xd7a65d);
    this.ellipsoid(this.organs,'adrenal-glands',[.105,1.065,.002],[.025,.012,.018],0xd7a65d);
    this.capsule(this.organs,[-.105,.95,.01],[-.025,.88,.025],.006,0xe2b46e,{id:'ureters'});
    this.capsule(this.organs,[.105,.95,.01],[.025,.88,.025],.006,0xe2b46e,{id:'ureters'});
    // Large and small intestines.
    const colon=this.mesh(new THREE.TorusGeometry(.075,.018,10,44),0xc98762,{parent:this.organs,pos:[0,1.005,.065],rot:[0,0,0],id:'large-intestine'}); colon.scale.set(1,.78,.65);
    for(let i=0;i<5;i++) this.mesh(new THREE.TorusGeometry(.027,.009,8,24,Math.PI*1.65),0xe2a77f,{parent:this.organs,pos:[(i%2?-.025:.025),.99-Math.floor(i/2)*.027,.088],rot:[0,0,(i%2)*.4],id:'small-intestine'});
    this.capsule(this.organs,[-.075,.98,.09],[-.095,.91,.09],.009,0xc98762,{id:'appendix'});
    this.capsule(this.organs,[0,.94,.045],[0,.87,.045],.009,0xc98762,{id:'rectum'});
    // Pelvic organs.
    this.ellipsoid(this.organs,'bladder',[0,.88,.055],[.038,.045,.035],0xe2c16d);
    this.ellipsoid(this.organs,'reproductive-system',[0,.82,.005],[.045,.035,.025],0xb87a9c);
    // Pelvis and long bones.
    this.mesh(new THREE.TorusGeometry(.105,.018,10,32),bone,{parent:this.skeleton,pos:[0,.88,0],rot:[Math.PI/2,0,0],layer:'skeleton',id:'pelvis'});
    // Arms and shoulders: skeleton + muscle layer.
    for(const s of [-1,1]) {
      this.ellipsoid(this.skeleton,'shoulders',[s*.205,1.47,0],[.055,.06,.055],bone,'skeleton',.9);
      this.capsule(this.skeleton,[s*.22,1.45,0],[s*.285,1.20,0],.018,bone,{id:'humerus',layer:'skeleton'});
      this.ellipsoid(this.skeleton,'elbows',[s*.285,1.20,0],[.025,.025,.025],bone,'skeleton');
      this.capsule(this.skeleton,[s*.285,1.19,0],[s*.30,.98,.015],.012,bone,{id:'forearm-bones',layer:'skeleton'});
      this.ellipsoid(this.skeleton,'hands',[s*.30,.95,.02],[.032,.055,.018],bone,'skeleton');
      this.capsule(this.muscles,[s*.22,1.45,.015],[s*.285,1.20,.015],.042,muscle,{id:'arm-muscles',layer:'muscles',opacity:.52});
      this.capsule(this.muscles,[s*.285,1.19,.015],[s*.30,.98,.02],.029,muscle,{id:'arm-muscles',layer:'muscles',opacity:.5});
    }
    // Torso muscle groups and abdominal segmentation.
    this.ellipsoid(this.muscles,'chest-muscles',[0,1.40,.025],[.17,.12,.065],muscle,'muscles',.36);
    for(const x of [-.055, .055]) for(let i=0;i<3;i++) this.ellipsoid(this.muscles,'abdominal-muscles',[x,1.19-i*.055,.065],[.042,.022,.018],0xb75b50,'muscles',.5);
    // Legs and wearable band; the left/right lower-limb hierarchy is animated from ankle/EMG.
    for(const side of ['left','right']) this.legs[side]=this.buildLeg(side==='left'?1:-1);
  }
  buildLeg(sx) {
    const hip=this.group(this.root, sx>0?'left-leg':'right-leg'); hip.position.set(sx*.095,.88,0);
    this.capsule(this.skeleton,[0,0,0],[0,-.39,0],.022,COLORS.bone,{parent:hip,id:'femur',layer:'skeleton'});
    this.capsule(this.muscles,[0,-.02,.018],[0,-.37,.018],.055,COLORS.muscle,{parent:hip,id:'thigh-muscles',layer:'muscles',opacity:.48});
    const knee=this.group(hip,'knee-joint'); knee.position.y=-.39;
    this.ellipsoid(this.skeleton,'kneecap',[0,0,.012],[.033,.04,.025],COLORS.bone,'skeleton');
    const calf=this.capsule(this.muscles,[0,-.04,.012],[0,-.39,.012],.043,COLORS.muscle,{parent:knee,id:'calf-muscles',layer:'muscles',opacity:.58});
    this.capsule(this.skeleton,[0,-.03,-.005],[0,-.39,-.005],.014,COLORS.bone,{parent:knee,id:'tibia',layer:'skeleton'});
    this.capsule(this.skeleton,[.025,-.03,-.005],[.025,-.39,-.005],.008,COLORS.bone,{parent:knee,id:'fibula',layer:'skeleton'});
    const band=new THREE.Mesh(new THREE.TorusGeometry(.049,.012,10,32),this.material(0x38d6e8)); band.rotation.x=Math.PI/2; band.position.set(0,-.25,.005); this.wearables.add(band); knee.add(band);
    const pods=[]; for(const [x,z] of [[0,-.052],[.045,0],[-.045,0]]) { const p=new THREE.Mesh(new THREE.SphereGeometry(.011,12,10),this.material(0xe7f7ff,.98,0x0b6470)); p.position.set(x,-.25,z); knee.add(p); pods.push(p); }
    const ankle=this.group(knee,'ankle-joint'); ankle.position.y=-.39;
    this.ellipsoid(this.skeleton,'ankle-bones',[0,0,0],[.027,.027,.027],COLORS.bone,'skeleton');
    const foot=this.mesh(new THREE.BoxGeometry(.075,.04,.18),COLORS.skin,{parent:ankle,pos:[0,-.025,.055],layer:'skin',opacity:.85,id:'foot'});
    const pad=new THREE.Mesh(new THREE.PlaneGeometry(.07,.17),new THREE.MeshBasicMaterial({color:0x3355ff,transparent:true,opacity:.8,side:THREE.DoubleSide})); pad.rotation.x=Math.PI/2; pad.position.set(0,-.05,.055); pad.visible=false; ankle.add(pad);
    return {hip,knee,ankle,calf,foot,pad,band,pods};
  }
  resetView() {
    const movement=this.mode==='movement'; this.controls.target.set(0,movement?.43:.98,0);
    this.camera.position.set(movement?.85:0,movement?.55:1.02,movement?1.75:3.35); this.controls.update();
  }
  setLayer(layer,on) { const map={skin:this.shell,skeleton:this.skeleton,muscles:this.muscles,organs:this.organs}; if(map[layer]) map[layer].visible=!!on; (this.layerMeshes[layer]||[]).forEach(m=>m.visible=!!on); }
  setAllLayers(on) { [this.shell,this.skeleton,this.muscles,this.organs].forEach(g=>g.visible=!!on); Object.values(this.layerMeshes).flat().forEach(m=>m.visible=!!on); }
  setActiveLeg(side) { this.resetLeg(this.leg); this.leg=side; }
  resetLeg(side) { const l=this.legs[side]; if(!l)return; l.ankle.rotation.x=0; l.pad.visible=false; l.calf.material.emissive.set(0); }
  setSensors(d) { this.target.ankle=d&&d.ankleAngle!=null?d.ankleAngle:0; this.target.emg=d&&d.emg!=null?d.emg:0; this.target.pressure=d&&d.footPressure!=null?d.footPressure:null; return {visualClamped:!!d&&d.ankleAngle!=null&&Math.abs(d.ankleAngle)>45}; }
  select(id) { for(const k in this.registry) for(const m of this.registry[k]) m.material.emissive.set(k===id?0x1a8294:0x000000); this.selected=id; }
  click(e) { const r=this.renderer.domElement.getBoundingClientRect(); this.ptr.set(((e.clientX-r.left)/r.width)*2-1,-((e.clientY-r.top)/r.height)*2+1); this.ray.setFromCamera(this.ptr,this.camera); const isShown=m=>{let n=m;while(n){if(!n.visible)return false;n=n.parent;}return true;}; const hit=this.ray.intersectObjects(this.pick.filter(isShown),false)[0]; if(hit){this.select(hit.object.userData.id);this.onSelect(hit.object.userData.id);} }
  resize() { const w=this.el.clientWidth||300,h=this.el.clientHeight||300; this.renderer.setSize(w,h,false); this.camera.aspect=w/h; this.camera.updateProjectionMatrix(); }
  setActive(on) { this.active=on; if(on)this.resize(); }
  loop() { requestAnimationFrame(this.loop); if(!this.active)return; const L=this.legs[this.leg]; if(!L)return; const k=.15,a=clamp(this.target.ankle,-45,45); this.cur.ankle+=(a-this.cur.ankle)*k; this.cur.emg+=(this.target.emg-this.cur.emg)*k; L.ankle.rotation.x=-THREE.MathUtils.degToRad(this.cur.ankle); L.calf.material.emissive.setRGB(this.cur.emg/100*.9,this.cur.emg/100*.35,0); L.band.material.color.set(this.cur.emg>65?0xffb454:0x38d6e8); L.pods.forEach(p=>p.material.emissiveIntensity=.35+this.cur.emg/100*1.1); if(this.target.pressure==null)L.pad.visible=false;else{L.pad.visible=true;L.pad.material.color.copy(heat(this.target.pressure/100));} this.controls.update(); this.renderer.render(this.scene,this.camera); }
}
