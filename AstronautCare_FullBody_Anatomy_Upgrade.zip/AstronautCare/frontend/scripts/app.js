import { BodyViewer } from './body.js';

const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const SENSORS = [
  { key: 'heartRate', label: 'Heart rate', unit: 'bpm', dec: 0 }, { key: 'spo2', label: 'SpO2', unit: '%', dec: 1 },
  { key: 'temperature', label: 'Temperature', unit: '°C', dec: 1 }, { key: 'emg', label: 'EMG (muscle activity)', unit: '% of range', dec: 0 },
  { key: 'ankleAngle', label: 'Ankle angle', unit: '°', dec: 1 }, { key: 'footPressure', label: 'Foot pressure', unit: '% of range', dec: 0 },
];
const SRC = { 'wokwi-simulation': ['Wokwi simulation', 'sim'], 'demo-generator': ['Demo generator', 'demo'], 'real-hardware': ['Real hardware', 'real'] };
const S = { snap: null, down: false, lastTs: 0, viewers: {}, organs: [], charts: {}, leg: 'left', virtualTimer: null, virtualTick: 0 };

// ---------- status ----------
function age() { return S.snap?.latest ? S.snap.serverTime - S.snap.latest.ts : Infinity; }
function mode() {
  if (S.down) return ['down', 'Server unreachable'];
  if (!S.snap?.latest) return ['none', 'No data received'];
  const [name, kind] = SRC[S.snap.latest.source] || ['Unknown source', 'none'];
  if (age() > 5) return ['stale', `Connection lost. Last update ${new Date(S.snap.latest.ts * 1000).toLocaleTimeString()}`];
  return [kind === 'demo' ? 'demo' : 'live', `${name} · updated ${new Date(S.snap.latest.ts * 1000).toLocaleTimeString()}`];
}
const live = () => (age() <= 5 ? S.snap.latest : null);
const tag = src => { const [n, k] = SRC[src] || [src, '']; return `<span class="tag ${k}">${esc(n)}</span>`; };
const fmt = (v, d) => (v == null ? '<span class="na">no data</span>' : Number(v).toFixed(d));

// ---------- router ----------
const PAGES = ['home', 'anatomy', 'sensors', 'movement', 'ai', 'research', 'fes', 'reports'];
function route() {
  const [name, qs] = (location.hash.slice(1) || 'home').split('?');
  const p = PAGES.includes(name) ? name : 'home';
  PAGES.forEach(x => $('#page-' + x).classList.toggle('on', x === p));
  document.querySelectorAll('#nav a').forEach(a => a.classList.toggle('on', a.hash === '#' + p));
  ensureViewer(p);
  for (const k in S.viewers) S.viewers[k].setActive(k === p);
  if (p === 'ai') { const o = new URLSearchParams(qs || '').get('organ'); if (o) { $('#ai-organ').value = o; runAI(); } }
  if (p === 'reports') loadReport();
  render();
}
function ensureViewer(p) {
  if (S.viewers[p] || !(p === 'anatomy' || p === 'movement')) return;
  try {
    S.viewers[p] = new BodyViewer($('#viewer-' + p), { mode: p, onSelect: p === 'anatomy' ? showOrgan : () => {} });
  } catch (e) { $('#viewer-' + p).innerHTML = '<p class="card">3D could not start (WebGL unavailable): ' + esc(e.message) + '</p>'; }
}

// ---------- render ----------
function render() {
  const [cls, text] = mode();
  $('#status').className = 'pill ' + cls; $('#status span').textContent = text;
  const l = live(), cards = SENSORS.map(s => `<div class="card"><div class="lbl">${s.label}</div><div class="val">${fmt(l?.[s.key], s.dec)} <small>${l?.[s.key] != null ? s.unit : ''}</small></div></div>`).join('');
  $('#home-sensors').innerHTML = cards;
  $('#source-note').innerHTML = S.snap?.latest ? `Latest packet source: ${tag(S.snap.latest.source)}. Alerts shown by the simulation use demo thresholds, not medical limits.` : 'No packets yet. Start the bridge (simulation/README.md) or enable demo data below.';
  $('#demo-toggle').checked = !!S.snap?.demo;
  $('#sim-start').disabled = !!S.virtualTimer; $('#sim-stop').disabled = !S.virtualTimer;
  if (!S.virtualTimer && $('#sim-state')) $('#sim-state').textContent = 'Stopped. Start the simulator to send changing readings to the dashboard and 3D leg.';
  // sensor grid values
  SENSORS.forEach(s => { const e = $('#sv-' + s.key); if (e) e.innerHTML = fmt(l?.[s.key], s.dec) + ' <small>' + (l?.[s.key] != null ? s.unit : '') + '</small>'; });
  // movement
  const L = S.leg;
  $('#mv-leg').textContent = `(${L} leg, assumed placement)`;
  $('#mv-readings').innerHTML = ['ankleAngle', 'emg', 'footPressure'].map(k => { const s = SENSORS.find(x => x.key === k); return `<div class="rd"><span>${s.label}</span><b>${fmt(l?.[k], s.dec)} ${l?.[k] != null ? s.unit : ''}</b></div>`; }).join('');
  const mv = S.viewers.movement, anat = S.viewers.anatomy;
  let clamp = { visualClamped: false };
  if (mv) { mv.setActiveLeg(L); clamp = mv.setSensors(l); }
  $('#mv-note').textContent = !l ? 'No live data: the model stays neutral and nothing is invented.' :
    (clamp.visualClamped ? 'Reading exceeds a plausible ankle range; the 3D foot is limited to ±45°. Numbers show the raw value.' : 'The simulation has one ankle, one EMG and one pressure channel; they are applied to the selected leg. Positive angle is drawn as toes up (assumed).');
  if (anat) anat.setSensors(null);
  // fes
  const f = l?.fesEnabled;
  $('#fes-grid').innerHTML = [
    ['Virtual FES switch (GPIO18)', f == null ? '<span class="na">no data</span>' : (f ? 'ON (simulated)' : 'OFF (simulated)'), 'Simulation switch state only. Nothing is stimulated.'],
    ['Band link', l ? 'Receiving data' : 'No data', S.snap?.latest ? tag(S.snap.latest.source) : ''],
    ['Alert LED (GPIO5)', l?.redAlert == null ? '<span class="na">no data</span>' : (l.redAlert ? '<span class="alert">Red alert</span>' : 'Clear'), l?.alerts?.length ? 'Triggered: ' + l.alerts.map(esc).join(', ') + ' (demo thresholds)' : ''],
    ['Sensor activity', SENSORS.map(s => `${l?.[s.key] != null ? '●' : '○'} ${s.label}`).join('<br>'), '● receiving, ○ missing'],
    ['Medical device status', 'Not connected', 'This app has no stimulator control.'],
  ].map(([a, b, c]) => `<div class="card"><div class="lbl">${a}</div><div class="val" style="font-size:1.2rem">${b}</div><p class="hint">${c}</p></div>`).join('');
}


// ---------- browser-only virtual sensor laboratory ----------
function scenarioPacket(kind, t) {
  const wave = (period, amplitude, phase = 0) => Math.sin((t / period) + phase) * amplitude;
  const noise = amount => (Math.random() - 0.5) * amount;
  const profiles = {
    rest:     { hr: 68, hrA: 3, emg: 12, emgA: 5, ankle: 2, ankleA: 3, pressure: 22, pressureA: 5, temp: 36.5, spo2: 98 },
    walk:     { hr: 88, hrA: 7, emg: 48, emgA: 25, ankle: 0, ankleA: 24, pressure: 52, pressureA: 28, temp: 36.7, spo2: 97 },
    exercise: { hr: 116, hrA: 9, emg: 72, emgA: 20, ankle: 0, ankleA: 32, pressure: 65, pressureA: 24, temp: 37.1, spo2: 96 },
    recovery:{ hr: 82, hrA: 8, emg: 24, emgA: 8, ankle: 0, ankleA: 7, pressure: 30, pressureA: 7, temp: 36.7, spo2: 97 }
  };
  const p = profiles[kind] || profiles.walk;
  const gait = Math.sin(t * 1.15);
  return {
    heartRate: +(p.hr + wave(4.5, p.hrA) + noise(1.4)).toFixed(1),
    spo2: +(p.spo2 + wave(11, .4) + noise(.2)).toFixed(1),
    temperature: +(p.temp + wave(22, .12) + noise(.04)).toFixed(2),
    emg: +Math.max(0, Math.min(100, p.emg + wave(1.8, p.emgA) + noise(4))).toFixed(1),
    ankleAngle: +(p.ankle + gait * p.ankleA + noise(1.5)).toFixed(1),
    footPressure: +Math.max(0, Math.min(100, p.pressure + Math.abs(gait) * p.pressureA + noise(3))).toFixed(1),
    fesEnabled: false,
    redAlert: false,
    alerts: [],
    _source: 'demo-generator'
  };
}
async function sendVirtualReading() {
  const kind = $('#sim-scenario').value;
  const packet = scenarioPacket(kind, S.virtualTick++);
  try {
    const response = await fetch('/api/ingest', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(packet) });
    if (!response.ok) throw new Error((await response.json()).error || `HTTP ${response.status}`);
    $('#sim-state').textContent = `Running · ${kind} scenario · sending simulated readings every second`;
    $('#sim-values').innerHTML = SENSORS.map(x => `<span><b>${x.label}</b> ${packet[x.key]} ${x.unit}</span>`).join('');
    return true;
  } catch (e) {
    $('#sim-state').textContent = `Could not send virtual readings: ${e.message}. Check that the Flask server is running.`;
    return false;
  }
}
async function startVirtualSimulation() {
  if (S.virtualTimer) return;
  // Avoid two demo generators writing at the same time.
  try { await fetch('/api/demo', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ enabled: false }) }); } catch {}
  S.virtualTick = 0;
  const sent = await sendVirtualReading();
  if (sent) S.virtualTimer = setInterval(sendVirtualReading, 1000);
  $('#sim-start').disabled = !!S.virtualTimer; $('#sim-stop').disabled = !S.virtualTimer;
}
function stopVirtualSimulation() {
  if (S.virtualTimer) clearInterval(S.virtualTimer);
  S.virtualTimer = null;
  $('#sim-start').disabled = false; $('#sim-stop').disabled = true;
  if ($('#sim-state')) $('#sim-state').textContent = 'Stopped. Previously received readings remain in history.';
}

// ---------- charts ----------
function mkChart(el, series) {
  return new Chart(el, { type: 'line', data: { labels: [], datasets: series.map(s => ({ label: s.label, data: [], borderColor: s.color, borderWidth: 1.5, pointRadius: 0, tension: .25, spanGaps: false })) },
    options: { animation: false, responsive: true, scales: { x: { ticks: { color: '#8397b8', maxTicksLimit: 5 } }, y: { ticks: { color: '#8397b8' }, grid: { color: '#1d2b4d' } } }, plugins: { legend: { labels: { color: '#8397b8' }, display: series.length > 1 } } } });
}
function push(ch, ts, vals, max = 90) {
  ch.data.labels.push(new Date(ts * 1000).toLocaleTimeString()); vals.forEach((v, i) => ch.data.datasets[i].data.push(v));
  if (ch.data.labels.length > max) { ch.data.labels.shift(); ch.data.datasets.forEach(d => d.data.shift()); }
  ch.update('none');
}
function initCharts() {
  $('#sensor-grid').innerHTML = SENSORS.map(s => `<div class="card"><div class="lbl">${s.label}</div><div class="val" id="sv-${s.key}"></div><canvas id="ch-${s.key}" height="110"></canvas></div>`).join('');
  const colors = ['#ff6b6b', '#38d6e8', '#ffb454', '#b794f6', '#3ddc97', '#6ea8ff'];
  SENSORS.forEach((s, i) => S.charts[s.key] = mkChart($('#ch-' + s.key), [{ label: s.label, color: colors[i] }]));
  S.charts.mv = mkChart($('#mv-chart'), [{ label: 'Ankle angle (°)', color: '#3ddc97' }]);
}
async function preload() {
  try { const rows = await (await fetch('/api/history?minutes=5&limit=90')).json(); rows.forEach(r => addPoint(r)); } catch { /* ignore */ }
}
function addPoint(r) {
  SENSORS.forEach(s => push(S.charts[s.key], r.ts, [r[s.key]]));
  push(S.charts.mv, r.ts, [r.ankleAngle]);
}

// ---------- stream ----------
function connect() {
  const es = new EventSource('/api/stream');
  es.onmessage = e => {
    try {
      S.down = false; S.snap = JSON.parse(e.data);
      const p = S.snap.latest;
      if (p && p.ts !== S.lastTs) { S.lastTs = p.ts; addPoint(p); }
    } catch (err) { console.warn('bad stream message', err); }
    render();
  };
  es.onerror = () => { S.down = true; render(); }; // EventSource auto-reconnects
}

// ---------- organs / AI / research ----------
async function loadBandAIStatus() {
  const el = $('#band-ai-status');
  try {
    const response = await fetch('/api/services/status');
    const data = await response.json();
    const model = data.band_ai_demo || {};
    el.textContent = model.available
      ? `Model available · ${model.mode}. ${model.warning}`
      : `Model unavailable · ${model.error || 'runtime check failed'}. Install backend requirements and restart the server.`;
  } catch (error) {
    el.textContent = `Could not check model status: ${error.message}`;
  }
}
async function loadOrgans() {
  try { S.organs = await (await fetch('/api/organs')).json(); } catch { S.organs = []; }
  $('#ai-organ').innerHTML = S.organs.map(o => `<option value="${o.id}">${esc(o.name)}</option>`).join('');
  const systems = [...new Set(S.organs.map(o => o.system))];
  $('#rs-sys').innerHTML += systems.map(s => `<option>${esc(s)}</option>`).join('');
}
function showOrgan(id) {
  const aliases = { 'ribcage':'spine', 'femur':'muscles', 'tibia':'muscles', 'fibula':'muscles', 'thigh-muscles':'muscles', 'calf-muscles':'muscles', 'arm-muscles':'muscles', 'chest-muscles':'muscles', 'abdominal-muscles':'muscles', 'humerus':'muscles', 'forearm-bones':'spine', 'shoulders':'muscles', 'elbows':'muscles', 'hands':'foot', 'kneecap':'knee', 'ankle-bones':'ankle' };
  const o = S.organs.find(x => x.id === id) || S.organs.find(x => x.id === aliases[id]); if (!o) return;
  const aiId = aliases[id] || id;
  $('#organ-panel').innerHTML = `<h3>${esc(o.name)}</h3><p class="lbl">${esc(o.system)}</p><p><b>Function.</b> ${esc(o.function)}</p><p><b>Anatomy.</b> ${esc(o.anatomy)}</p><a class="btn" href="#ai?organ=${aiId}">AI analysis with NASA sources</a><p class="hint">Static text written for this prototype, not from NASA.</p>`;
}
const srcHTML = list => list.map((s, i) => `<div class="src"><b>[${i + 1}] <a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.title)}</a></b><p>${esc(s.summary)}</p><span class="tag">${esc(s.organization)}</span> <span class="tag">${esc(s.date || 'date n/a')}</span></div>`).join('');
async function runAI() {
  const out = $('#ai-out'); out.innerHTML = '<p>Retrieving sources…</p>';
  try {
    const r = await (await fetch('/api/analyze', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ organ: $('#ai-organ').value }) })).json();
    if (r.error) throw new Error(r.error);
    out.innerHTML = `<h3>${esc(r.organ)} <span class="tag">${esc(r.system)}</span></h3><p><b>Function.</b> ${esc(r.function)}</p><p><b>Anatomy.</b> ${esc(r.anatomy)}</p>` +
      (r.analysis ? `<h3>Spaceflight analysis ${r.ai_used ? '<span class="tag">AI-generated from sources below</span>' : ''}</h3><div style="white-space:pre-wrap">${esc(r.analysis)}</div>` : '') +
      (r.notice ? `<p class="banner">${esc(r.notice)}</p>` : '') +
      (r.retrieval_errors?.length ? `<p class="hint">Retrieval problems: ${r.retrieval_errors.map(esc).join('; ')}</p>` : '') +
      `<h3>Sources</h3>${r.sources.length ? srcHTML(r.sources) : '<p>No sources retrieved.</p>'}<p class="hint">${esc(r.disclaimer)}</p>`;
  } catch (e) { out.innerHTML = `<p class="alert">Analysis failed: ${esc(e.message)}</p>`; }
}
async function runResearch(ev) {
  ev.preventDefault();
  const sys = $('#rs-sys').value, q = $('#rs-q').value.trim() || (S.organs.find(o => o.system === sys)?.name || '');
  const out = $('#rs-out'); out.innerHTML = '<p>Searching NASA sources…</p>';
  try {
    const r = await (await fetch('/api/research?q=' + encodeURIComponent(q))).json();
    if (r.error) throw new Error(r.error);
    out.innerHTML = (r.notice ? `<p class="banner">${esc(r.notice)} (${r.count ?? r.results.length} records)</p>` : '') + (r.errors?.length ? `<p class="hint">${r.errors.map(esc).join('; ')}</p>` : '') + `<div class="card">${r.results.length ? srcHTML(r.results) : 'No results.'}</div>`;
  } catch (e) { out.innerHTML = `<p class="alert">Search failed: ${esc(e.message)}</p>`; }
}

// ---------- reports ----------
async function loadReport() {
  const m = $('#rp-range').value; $('#rp-csv').href = `/api/export.csv?minutes=${m}`;
  try {
    const rows = await (await fetch(`/api/history?minutes=${m}&limit=2000`)).json();
    if (S.charts.rp) S.charts.rp.destroy();
    const step = Math.max(1, Math.floor(rows.length / 300)), pts = rows.filter((_, i) => i % step === 0);
    S.charts.rp = mkChart($('#rp-chart'), [{ label: 'Ankle angle', color: '#3ddc97' }, { label: 'EMG', color: '#ffb454' }, { label: 'Foot pressure', color: '#6ea8ff' }]);
    pts.forEach(r => push(S.charts.rp, r.ts, [r.ankleAngle, r.emg, r.footPressure], 1e9));
    const by = {}; rows.forEach(r => by[r.source] = (by[r.source] || 0) + 1);
    $('#rp-sum').innerHTML = `<b>${rows.length}</b> records. Sources: ` + (Object.entries(by).map(([k, v]) => `${tag(k)} ${v}`).join(' ') || 'none');
    $('#rp-table').innerHTML = '<tr><th>Time</th><th>Source</th>' + SENSORS.map(s => `<th>${s.label}</th>`).join('') + '</tr>' +
      rows.slice(-25).reverse().map(r => `<tr><td>${new Date(r.ts * 1000).toLocaleTimeString()}</td><td>${tag(r.source)}</td>${SENSORS.map(s => `<td>${r[s.key] ?? '–'}</td>`).join('')}</tr>`).join('');
  } catch (e) { $('#rp-sum').textContent = 'Could not load history: ' + e.message; }
}

// ---------- wiring ----------
$('#anatomy-layers').addEventListener('click', e => { const b=e.target.closest('button[data-layer]'); if(!b)return; const v=S.viewers.anatomy, key=b.dataset.layer; if(!v)return; if(key==='reset'){v.resetView();return;} if(key==='all'){v.setAllLayers(true); document.querySelectorAll('#anatomy-layers [data-layer]').forEach(x=>{if(!['reset','all'].includes(x.dataset.layer))x.setAttribute('aria-pressed','true');});return;} const on=b.getAttribute('aria-pressed')!=='true'; v.setLayer(key,on); b.setAttribute('aria-pressed',String(on)); });
$('#leg-select').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; S.leg = b.dataset.leg; document.querySelectorAll('#leg-select button').forEach(x => x.classList.toggle('on', x === b)); render(); });
$('#demo-toggle').addEventListener('change', e => { if (e.target.checked) stopVirtualSimulation(); fetch('/api/demo', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ enabled: e.target.checked }) }); });
$('#sim-start').addEventListener('click', startVirtualSimulation); $('#sim-stop').addEventListener('click', stopVirtualSimulation);
$('#ai-run').addEventListener('click', runAI); $('#rs-form').addEventListener('submit', runResearch); $('#rp-load').addEventListener('click', loadReport);
window.addEventListener('hashchange', route);
window.addEventListener('beforeunload', stopVirtualSimulation);
initCharts(); loadOrgans().then(() => route()); loadBandAIStatus(); preload().then(connect);
setInterval(render, 2000);
