"""
generate_data.py
Generates SIMULATED sensor data for the Space Band (astronaut leg band).

Sensors inside the band:
  - heart rate (bpm)
  - SpO2 (%)
  - skin temperature (deg C)
  - EMG: amplitude (RMS, uV) and median frequency (Hz; drops with fatigue)
  - ankle: range of motion (deg) and angular velocity (deg/s)
  - foot: plantar pressure (kPa)
  - days_in_orbit (mission context)

NOTE: the values are illustrative, built from general physiology trends
(not clinical data). Replace with real recordings when you have hardware.
"""
import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)

STATES = {
    0: "Normal",
    1: "Muscle_Atrophy_Risk",
    2: "Muscle_Fatigue",
    3: "Poor_Circulation",
    4: "Heat_Stress",
    5: "Critical_Emergency",
}

# (mean, std) per feature per state
FEATURES = ["hr", "spo2", "skin_temp", "emg_rms", "emg_median_freq",
            "ankle_rom", "ankle_velocity", "foot_pressure"]

PROFILES = {
    0: dict(hr=(72, 8),  spo2=(97.5, 1.0), skin_temp=(33.5, 0.6), emg_rms=(120, 25),
            emg_median_freq=(85, 8), ankle_rom=(45, 5), ankle_velocity=(60, 10), foot_pressure=(180, 25)),
    1: dict(hr=(70, 8),  spo2=(97.0, 1.0), skin_temp=(33.3, 0.6), emg_rms=(70, 20),
            emg_median_freq=(82, 9), ankle_rom=(33, 6), ankle_velocity=(45, 10), foot_pressure=(110, 25)),
    2: dict(hr=(100, 10), spo2=(96.5, 1.2), skin_temp=(34.2, 0.6), emg_rms=(190, 30),
            emg_median_freq=(58, 8), ankle_rom=(40, 6), ankle_velocity=(38, 10), foot_pressure=(160, 30)),
    3: dict(hr=(88, 10), spo2=(94.5, 1.3), skin_temp=(30.5, 0.9), emg_rms=(105, 25),
            emg_median_freq=(80, 9), ankle_rom=(42, 6), ankle_velocity=(55, 10), foot_pressure=(150, 30)),
    4: dict(hr=(108, 10), spo2=(96.0, 1.2), skin_temp=(37.0, 0.6), emg_rms=(140, 30),
            emg_median_freq=(72, 9), ankle_rom=(42, 6), ankle_velocity=(50, 10), foot_pressure=(170, 30)),
    5: dict(hr=(110, 40), spo2=(86.0, 3.0), skin_temp=(34.0, 2.5), emg_rms=(90, 40),
            emg_median_freq=(70, 15), ankle_rom=(30, 10), ankle_velocity=(30, 15), foot_pressure=(120, 40)),
}

PRIORS = {0: 0.40, 1: 0.14, 2: 0.15, 3: 0.12, 4: 0.12, 5: 0.07}


def make_dataset(n=12000, label_noise=0.02):
    labels = RNG.choice(list(PRIORS), size=n, p=list(PRIORS.values()))
    rows = []
    for y in labels:
        p = PROFILES[y]
        r = {f: RNG.normal(*p[f]) for f in FEATURES}
        # critical state: either tachycardia or bradycardia
        if y == 5:
            r["hr"] = RNG.normal(145, 10) if RNG.random() < 0.5 else RNG.normal(40, 5)
        # mission context: atrophy is more likely later in the mission
        r["days_in_orbit"] = int(np.clip(RNG.normal(120 if y == 1 else 70, 40), 0, 240))
        r["label"] = y
        rows.append(r)
    df = pd.DataFrame(rows)

    # physical clipping
    df["spo2"] = df["spo2"].clip(70, 100)
    df["hr"] = df["hr"].clip(30, 200)
    df["skin_temp"] = df["skin_temp"].clip(25, 41)
    for c in ["emg_rms", "emg_median_freq", "ankle_rom", "ankle_velocity", "foot_pressure"]:
        df[c] = df[c].clip(lower=1)

    # a little label noise so the task is not unrealistically perfect
    flip = RNG.random(len(df)) < label_noise
    df.loc[flip, "label"] = RNG.choice(list(PRIORS), size=flip.sum())

    df["state"] = df["label"].map(STATES)
    return df.round(2)


if __name__ == "__main__":
    df = make_dataset()
    df.to_csv("astronaut_data.csv", index=False)
    print(df["state"].value_counts())
    print("saved astronaut_data.csv", df.shape)
