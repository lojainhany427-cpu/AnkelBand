# Space Band – AI Model

موديل الذكاء الاصطناعي للباند الذكي لرائد الفضاء.

## الملفات
| ملف | وظيفته |
|---|---|
| `generate_data.py` | يولّد داتا محاكاة للسينسورز (HR, SpO2, Temp, EMG, Ankle, Foot) |
| `train_model.py` | يدرّب 3 موديلات ويختار الأفضل ويحفظه + رسومات التقييم |
| `recommender.py` | المخ: طبقة أمان + الموديل + الاقتراحات + JSON للتطبيق (3D Body) |

## التشغيل
```
python generate_data.py
python train_model.py
python recommender.py
```
المتطلبات: numpy, pandas, scikit-learn, joblib, matplotlib

## الاستخدام من التطبيق
```python
from recommender import analyze
result = analyze({"hr":72,"spo2":98,"skin_temp":33.5,"emg_rms":120,
                  "emg_median_freq":85,"ankle_rom":46,"ankle_velocity":60,
                  "foot_pressure":185,"days_in_orbit":30})
# result["body"]  -> ألوان كل جزء في الـ 3D Body
# result["call_earth"] -> لو True افتح الفيديو كول
```

## الحالات الست
Normal · Muscle_Atrophy_Risk · Muscle_Fatigue · Poor_Circulation · Heat_Stress · Critical_Emergency
(+ Sensor_Error لو قراءة غير منطقية)

## تنبيه مهم
الداتا **محاكاة**، والأرقام والنصايح توضيحية للمشروع وليست نصيحة طبية.
دقة ~97% معناها إن الموديل اتعلم الأنماط اللي إحنا حطيناها في المحاكاة، مش دقة على رواد فضاء حقيقيين.
