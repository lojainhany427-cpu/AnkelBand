"""
train_model.py
Trains and compares 3 classifiers on the simulated band data,
keeps the best one (by cross-validated macro-F1), evaluates on a held-out
test set, and saves model + plots.
"""
import json
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay, f1_score
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from generate_data import STATES

FEATURES = ["hr", "spo2", "skin_temp", "emg_rms", "emg_median_freq",
            "ankle_rom", "ankle_velocity", "foot_pressure", "days_in_orbit"]

df = pd.read_csv("astronaut_data.csv")
X, y = df[FEATURES], df["label"]
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

candidates = {
    "LogisticRegression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000)),
    "RandomForest": RandomForestClassifier(n_estimators=300, min_samples_leaf=2,
                                           class_weight="balanced", random_state=42, n_jobs=-1),
    "GradientBoosting": HistGradientBoostingClassifier(max_iter=200, learning_rate=0.08, random_state=42),
}

cv = StratifiedKFold(5, shuffle=True, random_state=42)
scores = {}
for name, m in candidates.items():
    s = cross_val_score(m, X_tr, y_tr, cv=cv, scoring="f1_macro")
    scores[name] = (s.mean(), s.std())
    print(f"{name:20s} CV macro-F1 = {s.mean():.3f} +/- {s.std():.3f}")

best_name = max(scores, key=lambda k: scores[k][0])
best = candidates[best_name].fit(X_tr, y_tr)
pred = best.predict(X_te)
print(f"\nBest model: {best_name}")
target_names = [STATES[i] for i in sorted(STATES)]
print(classification_report(y_te, pred, target_names=target_names, digits=3))

# --- plots ---
fig, ax = plt.subplots(figsize=(7, 6))
ConfusionMatrixDisplay(confusion_matrix(y_te, pred), display_labels=target_names).plot(
    ax=ax, xticks_rotation=40, colorbar=False, cmap="Blues")
ax.set_title(f"Confusion matrix - {best_name}")
plt.tight_layout(); plt.savefig("confusion_matrix.png", dpi=150); plt.close()

if hasattr(best, "feature_importances_"):
    imp = pd.Series(best.feature_importances_, index=FEATURES).sort_values()
else:  # pipeline / models without built-in importances -> permutation importance
    from sklearn.inspection import permutation_importance
    r = permutation_importance(best, X_te, y_te, n_repeats=5, random_state=42, scoring="f1_macro")
    imp = pd.Series(r.importances_mean, index=FEATURES).sort_values()
fig, ax = plt.subplots(figsize=(7, 4))
imp.plot.barh(ax=ax, color="#2a6fdb")
ax.set_title("Which sensors matter most?")
plt.tight_layout(); plt.savefig("feature_importance.png", dpi=150); plt.close()

# --- save ---
joblib.dump({"model": best, "features": FEATURES, "states": STATES}, "space_band_model.joblib")
metrics = {
    "best_model": best_name,
    "cv_macro_f1": {k: round(v[0], 4) for k, v in scores.items()},
    "test_macro_f1": round(f1_score(y_te, pred, average="macro"), 4),
    "test_accuracy": round(float((pred == y_te).mean()), 4),
}
json.dump(metrics, open("metrics.json", "w"), indent=2)
print(metrics)
