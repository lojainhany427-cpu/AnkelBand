"""NASA source retrieval (NTRS + OSDR). Returns only records supplied by NASA APIs."""
import time
import requests

UA = {"User-Agent": "AstronautCare-prototype/0.2 (educational research viewer)"}
_cache = {}

def _cached(key, fn, ttl=900):
    hit = _cache.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    val = fn()
    _cache[key] = (time.time(), val)
    return val

def search_ntrs(query, size=8):
    """NASA Technical Reports Server public citation search."""
    r = requests.get("https://ntrs.nasa.gov/api/citations/search",
                     params={"q": query, "page.size": size}, headers=UA, timeout=20)
    r.raise_for_status()
    data = r.json()
    records = data.get("results", []) if isinstance(data, dict) else []
    out = []
    for it in records:
        if not isinstance(it, dict):
            continue
        cid, title = it.get("id"), it.get("title")
        if not cid or not title:
            continue
        date = (it.get("distributionDate") or it.get("created") or "")[:10] or None
        out.append({"title": str(title), "summary": str(it.get("abstract") or "No abstract provided by source.")[:700],
                    "organization": "NASA Technical Reports Server (NTRS)", "date": date,
                    "url": f"https://ntrs.nasa.gov/citations/{cid}", "source_type": "technical_report"})
    return out

def _osdr_records(data):
    """Handle known OSDR search response shapes without guessing missing fields."""
    if not isinstance(data, dict):
        return []
    if isinstance(data.get("studies"), list):
        return data["studies"]
    hits = data.get("hits")
    if isinstance(hits, dict) and isinstance(hits.get("hits"), list):
        return hits["hits"]
    if isinstance(data.get("results"), list):
        return data["results"]
    return []

def search_osdr(query, size=6):
    """NASA Open Science Data Repository public study search."""
    r = requests.get("https://osdr.nasa.gov/osdr/data/search",
                     params={"term": query, "type": "cgene", "size": size}, headers=UA, timeout=20)
    r.raise_for_status()
    out = []
    for h in _osdr_records(r.json()):
        if not isinstance(h, dict):
            continue
        src = h.get("_source", h)
        if not isinstance(src, dict):
            continue
        acc = src.get("Accession") or src.get("accession") or h.get("_id")
        title = src.get("Study Title") or src.get("title") or src.get("Title")
        if not acc or not str(acc).upper().startswith("OSD") or not title:
            continue
        description = src.get("Study Description") or src.get("description") or "Open dataset record; consult the NASA record for details."
        date = src.get("Study Public Release Date") or src.get("releaseDate") or None
        out.append({"title": f"{acc}: {title}", "summary": str(description)[:700],
                    "organization": "NASA Open Science Data Repository (OSDR)", "date": date,
                    "url": f"https://osdr.nasa.gov/bio/repo/data/studies/{acc}", "source_type": "dataset"})
    return out

def search_all(query):
    errors, results = [], []
    for name, fn in (("NTRS", search_ntrs), ("OSDR", search_osdr)):
        try:
            results.extend(_cached((name, query), lambda fn=fn: fn(query)))
        except requests.RequestException as e:
            errors.append(f"{name}: network/API request failed ({type(e).__name__}).")
        except (ValueError, TypeError, KeyError) as e:
            errors.append(f"{name}: response could not be parsed ({type(e).__name__}).")
    # Stable de-duplication by URL.
    unique, seen = [], set()
    for item in results:
        if item["url"] not in seen:
            seen.add(item["url"]); unique.append(item)
    return {"results": unique, "errors": errors, "query": query, "count": len(unique)}
