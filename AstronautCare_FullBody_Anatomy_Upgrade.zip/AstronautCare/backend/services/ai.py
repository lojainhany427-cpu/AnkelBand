"""Organ education: retrieval (NASA sources) + optional LLM synthesis, server-side only."""
import os
import requests
from .nasa import search_all

# General anatomy facts (hand-written, NOT from NASA). Kept short and conservative.
ORGANS = {
    "brain": ("Brain", "Nervous system", "Integrates sensory input, controls movement, cognition and autonomic regulation.", "Cerebrum, cerebellum and brainstem, protected by the skull and meninges.", "brain spaceflight neuroscience"),
    "skull": ("Skull", "Skeletal system", "Protects the brain and supports facial structures.", "Cranial and facial bones joined by sutures.", "skull bone spaceflight"),
    "heart": ("Heart", "Cardiovascular system", "Pumps blood through the pulmonary and systemic circulation.", "Four chambers; located in the mediastinum between the lungs.", "cardiovascular heart spaceflight"),
    "lungs": ("Lungs", "Respiratory system", "Gas exchange: oxygen into blood, carbon dioxide out.", "Right lung has three lobes, left has two.", "lung pulmonary function spaceflight"),
    "liver": ("Liver", "Digestive / metabolic", "Metabolism, detoxification, bile production, protein synthesis.", "Largest internal organ, in the upper right abdomen.", "liver spaceflight"),
    "stomach": ("Stomach", "Digestive system", "Mixes food with acid and enzymes to begin digestion.", "J-shaped muscular sac in the upper left abdomen.", "gastrointestinal stomach spaceflight"),
    "kidneys": ("Kidneys", "Urinary system", "Filter blood, regulate fluid, electrolytes and blood pressure.", "Paired retroperitoneal organs at the lower ribs.", "kidney renal spaceflight"),
    "intestines": ("Intestines", "Digestive system", "Nutrient and water absorption; hosts the gut microbiome.", "Small intestine (duodenum, jejunum, ileum) then large intestine.", "gut microbiome intestine spaceflight"),
    "bladder": ("Urinary bladder", "Urinary system", "Stores urine until voiding.", "Muscular reservoir in the pelvis.", "urinary bladder spaceflight"),
    "spine": ("Spine", "Skeletal / nervous", "Supports the trunk and protects the spinal cord.", "24 mobile vertebrae plus sacrum and coccyx.", "spine intervertebral disc spaceflight"),
    "pelvis": ("Pelvis", "Skeletal system", "Transfers load from trunk to legs; houses pelvic organs.", "Hip bones, sacrum and coccyx.", "bone loss pelvis spaceflight"),
    "muscles": ("Skeletal muscles (legs)", "Muscular system", "Generate force for movement and posture.", "Thigh and calf muscle groups act across knee and ankle.", "skeletal muscle atrophy spaceflight"),
    "knee": ("Knee joint", "Musculoskeletal", "Hinge joint enabling leg flexion and extension.", "Femur, tibia, patella, ligaments and menisci.", "knee joint spaceflight"),
    "ankle": ("Ankle joint", "Musculoskeletal", "Dorsiflexion/plantarflexion of the foot.", "Tibia, fibula and talus.", "ankle gait spaceflight"),
    "foot": ("Foot", "Musculoskeletal", "Bears weight and propels gait.", "26 bones; heel, arch and forefoot load areas.", "foot plantar loading spaceflight"),
    "eyes": ("Eyes", "Special senses", "Detect light and convert it into neural signals for vision.", "The retina, lens, cornea and optic nerve form the visual pathway.", "vision ocular changes spaceflight astronaut"),
    "trachea": ("Trachea", "Respiratory system", "Conducts air between the larynx and bronchi.", "A flexible airway supported by C-shaped cartilage rings.", "airway respiratory system spaceflight"),
    "esophagus": ("Esophagus", "Digestive system", "Moves swallowed food and liquid to the stomach.", "A muscular tube behind the trachea.", "esophagus digestion spaceflight"),
    "pancreas": ("Pancreas", "Digestive / endocrine", "Produces digestive enzymes and hormones including insulin and glucagon.", "An elongated gland behind the stomach.", "pancreas glucose metabolism spaceflight"),
    "spleen": ("Spleen", "Lymphatic / immune", "Filters blood and supports immune function.", "A soft organ in the upper left abdomen.", "spleen immune system spaceflight"),
    "small-intestine": ("Small intestine", "Digestive system", "Completes digestion and absorbs most nutrients.", "Duodenum, jejunum and ileum; highly folded and coiled.", "small intestine gastrointestinal spaceflight"),
    "large-intestine": ("Large intestine", "Digestive system", "Absorbs water and electrolytes and forms stool.", "Includes the cecum, colon, rectum and anal canal.", "colon large intestine spaceflight"),
    "reproductive-system": ("Reproductive organs", "Reproductive system", "Organs involved in human reproduction and hormone functions.", "The model shows a simplified pelvic representation, not sex-specific anatomy.", "reproductive health spaceflight"),
    "major-vessels": ("Major blood vessels", "Cardiovascular system", "Carry blood between the heart and body tissues.", "Includes the aorta, venae cavae and pulmonary vessels.", "cardiovascular circulation spaceflight"),
    "thyroid": ("Thyroid gland", "Endocrine system", "Produces hormones that help regulate metabolism.", "A butterfly-shaped gland in the front of the neck.", "thyroid endocrine metabolism spaceflight"),
    "diaphragm": ("Diaphragm", "Respiratory / muscular", "The main muscle driving breathing by changing chest cavity volume.", "A dome-shaped muscle separating thorax and abdomen.", "diaphragm respiratory muscle spaceflight"),
    "gallbladder": ("Gallbladder", "Digestive system", "Stores and concentrates bile produced by the liver.", "A small sac beneath the liver.", "gallbladder biliary digestive system"),
    "adrenal-glands": ("Adrenal glands", "Endocrine system", "Produce hormones involved in stress response, blood pressure and metabolism.", "Paired glands located above the kidneys.", "adrenal glands endocrine spaceflight"),
    "ureters": ("Ureters", "Urinary system", "Carry urine from each kidney to the urinary bladder.", "Two narrow muscular tubes.", "urinary tract kidney ureter"),
    "appendix": ("Appendix", "Digestive / immune", "A small pouch associated with gut immune tissue; its full role is still studied.", "A narrow extension from the cecum.", "appendix gut immune system"),
    "rectum": ("Rectum", "Digestive system", "Temporarily stores stool before elimination.", "The final segment of the large intestine.", "rectum large intestine"),
}

DISCLAIMER = "Educational information only. Not medical advice, diagnosis or treatment."


def organ_list():
    return [{"id": k, "name": v[0], "system": v[1], "function": v[2], "anatomy": v[3]} for k, v in ORGANS.items()]


def ai_status():
    """Safe configuration status; never returns the secret key."""
    return {"provider": "Anthropic", "configured": bool(os.environ.get("ANTHROPIC_API_KEY")),
            "model": os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5-5"),
            "note": "AI calls are server-side only. An API key may incur provider charges."}


def analyze_organ(organ_id):
    if organ_id not in ORGANS:
        raise KeyError(organ_id)
    name, system, function, anatomy, query = ORGANS[organ_id]
    found = search_all(query)
    sources = found["results"][:8]
    out = {"organ": name, "system": system, "function": function, "anatomy": anatomy,
           "sources": sources, "retrieval_errors": found["errors"],
           "disclaimer": DISCLAIMER, "ai_used": False, "analysis": None}

    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        out["notice"] = "AI synthesis is off (no ANTHROPIC_API_KEY on the server). Showing static anatomy and retrieved sources only."
        return out
    if not sources:
        out["notice"] = "No reliable NASA sources were retrieved, so no spaceflight claims are made."
        return out

    ctx = "\n".join(f"[{i+1}] {s['title']} ({s['organization']}, {s['date'] or 'n.d.'}): {s['summary']}" for i, s in enumerate(sources))
    system_prompt = ("You write short educational summaries about human anatomy and spaceflight research. "
                     "Make spaceflight claims ONLY if supported by the numbered sources, and cite them like [1]. "
                     "Never invent studies, numbers or authors. If sources do not address something, say 'No retrieved source covers this.' "
                     "No diagnosis, no treatment advice. Use three short sections: 'What the retrieved sources say', "
                     "'Possible effects (hedged)', 'Known vs uncertain'.")
    user = f"Organ: {name} ({system}).\nGeneral anatomy (not from NASA): {function} {anatomy}\n\nSources:\n{ctx}"
    try:
        r = requests.post("https://api.anthropic.com/v1/messages",
                          headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                          json={"model": os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5-5"), "max_tokens": 900,
                                "system": system_prompt, "messages": [{"role": "user", "content": user}]}, timeout=60)
        r.raise_for_status()
        content = r.json().get("content", [])
        out["analysis"] = "\n".join(b.get("text", "") for b in content if isinstance(b, dict) and b.get("type") == "text")
        if not out["analysis"].strip():
            out["notice"] = "The AI provider returned no text. Showing retrieved sources only."
        else:
            out["ai_used"] = True
    except requests.RequestException as e:
        out["notice"] = f"AI provider request failed ({type(e).__name__}). Showing retrieved sources only."
    except (ValueError, KeyError, TypeError) as e:
        out["notice"] = f"AI provider response could not be parsed ({type(e).__name__}). Showing retrieved sources only."
    return out
