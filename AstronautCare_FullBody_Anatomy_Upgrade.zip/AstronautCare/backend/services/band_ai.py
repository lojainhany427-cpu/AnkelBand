"""Isolated demo classifier for the synthetic Space Band dataset.

This model is NOT connected to the six live app channels: their units and
semantics do not match the model's nine training features. The endpoint accepts
only a complete, explicitly supplied feature vector and returns a descriptive
model label. It never controls FES, raises medical alarms, or gives treatment.
"""
from pathlib import Path
import math
import warnings

MODEL_PATH = Path(__file__).resolve().parents[1] / "models" / "space_band_model.joblib"
FEATURES = ["hr", "spo2", "skin_temp", "emg_rms", "emg_median_freq",
            "ankle_rom", "ankle_velocity", "foot_pressure", "days_in_orbit"]
RANGES = {
    "hr": (25, 220), "spo2": (60, 100), "skin_temp": (20, 43),
    "emg_rms": (0, 2000), "emg_median_freq": (5, 300),
    "ankle_rom": (0, 120), "ankle_velocity": (0, 500),
    "foot_pressure": (0, 1000), "days_in_orbit": (0, 2000),
}
_bundle = None
_load_error = None


def _load():
    global _bundle, _load_error
    if _bundle is not None:
        return _bundle
    if _load_error:
        raise RuntimeError(_load_error)
    if not MODEL_PATH.is_file():
        _load_error = "model file is missing"
        raise RuntimeError(_load_error)
    try:
        import joblib
        # The artifact was serialized with scikit-learn 1.9.1. Keep any
        # version warning visible in logs; do not silently claim compatibility.
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            _bundle = joblib.load(MODEL_PATH)
        version_warnings = [str(w.message) for w in caught if "InconsistentVersionWarning" in w.category.__name__]
        if version_warnings:
            _load_error = "scikit-learn version mismatch; install the training version (1.9.1) before using this model"
            _bundle = None
            raise RuntimeError(_load_error)
        if not isinstance(_bundle, dict) or not all(k in _bundle for k in ("model", "features", "states")):
            _load_error = "model bundle has an unexpected format"
            _bundle = None
            raise RuntimeError(_load_error)
        if list(_bundle["features"]) != FEATURES:
            _load_error = "model feature schema does not match the expected schema"
            _bundle = None
            raise RuntimeError(_load_error)
        return _bundle
    except RuntimeError:
        raise
    except Exception as exc:
        _load_error = f"model could not be loaded ({type(exc).__name__})"
        raise RuntimeError(_load_error) from exc


def status():
    try:
        _load()
        return {"available": True, "mode": "synthetic-demo-only", "features": FEATURES,
                "warning": "Trained and evaluated on synthetic data only; not validated on astronauts or people."}
    except RuntimeError as exc:
        return {"available": False, "mode": "synthetic-demo-only", "features": FEATURES,
                "error": str(exc)}


def analyze(payload):
    if not isinstance(payload, dict):
        raise ValueError("Request must be a JSON object.")
    missing = [f for f in FEATURES if f not in payload]
    if missing:
        raise ValueError("Missing required model features: " + ", ".join(missing))
    values = {}
    for name in FEATURES:
        value = payload[name]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError(f"{name} must be a finite number.")
        lo, hi = RANGES[name]
        if not lo <= float(value) <= hi:
            raise ValueError(f"{name} must be within the model input validation range {lo}..{hi}.")
        values[name] = float(value)
    bundle = _load()
    import pandas as pd
    frame = pd.DataFrame([[values[f] for f in FEATURES]], columns=FEATURES)
    model = bundle["model"]
    probabilities = model.predict_proba(frame)[0]
    idx = int(probabilities.argmax())
    states = bundle["states"]
    state = states.get(idx, states.get(str(idx), f"class_{idx}"))
    return {
        "state_label": str(state),
        "confidence": round(float(probabilities[idx]), 4),
        "probabilities": {str(states.get(i, states.get(str(i), f"class_{i}"))): round(float(p), 4)
                           for i, p in enumerate(probabilities)},
        "decision_source": "synthetic_trained_model",
        "notice": "Experimental classification from a synthetic dataset. Not a medical assessment, diagnosis, risk prediction, or treatment recommendation.",
        "fes_control": False,
        "automatic_alerts": False,
    }
