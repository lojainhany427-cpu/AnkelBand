"""Offline tests for NASA parsing and AI fallback/response handling."""
import os
import unittest
from unittest.mock import patch

from services import nasa, ai

class FakeResponse:
    def __init__(self, payload, status=200):
        self.payload = payload
        self.status_code = status
    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError("HTTP error")
    def json(self):
        return self.payload

class ServiceTests(unittest.TestCase):
    def setUp(self):
        nasa._cache.clear()

    @patch("services.nasa.requests.get")
    def test_ntrs_parser(self, get):
        get.return_value = FakeResponse({"results": [{"id": "20260001234", "title": "Spaceflight muscle study", "abstract": "Abstract", "created": "2026-01-02"}]})
        out = nasa.search_ntrs("muscle")
        self.assertEqual(len(out), 1)
        self.assertIn("ntrs.nasa.gov/citations/20260001234", out[0]["url"])

    @patch("services.nasa.requests.get")
    def test_osdr_parser(self, get):
        get.return_value = FakeResponse({"hits": {"hits": [{"_id": "OSD-123", "_source": {"Accession": "OSD-123", "Study Title": "Space biology dataset", "Study Description": "Study summary"}}]}})
        out = nasa.search_osdr("muscle")
        self.assertEqual(len(out), 1)
        self.assertIn("OSD-123", out[0]["title"])

    @patch("services.ai.search_all")
    def test_ai_fallback_without_key(self, search):
        search.return_value = {"results": [], "errors": ["offline"], "count": 0}
        with patch.dict(os.environ, {}, clear=True):
            out = ai.analyze_organ("heart")
        self.assertFalse(out["ai_used"])
        self.assertIsNone(out["analysis"])
        self.assertIn("ANTHROPIC_API_KEY", out["notice"])

    @patch("services.ai.requests.post")
    @patch("services.ai.search_all")
    def test_ai_success_response_shape(self, search, post):
        search.return_value = {"results": [{"title": "NASA study", "organization": "NASA", "date": None, "summary": "Source summary", "url": "https://example.org"}], "errors": [], "count": 1}
        post.return_value = FakeResponse({"content": [{"type": "text", "text": "What the retrieved sources say: sample [1]."}]})
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "test-key", "ANTHROPIC_MODEL": "claude-sonnet-5-5"}):
            out = ai.analyze_organ("heart")
        self.assertTrue(out["ai_used"])
        self.assertIn("[1]", out["analysis"])
        self.assertEqual(post.call_args.kwargs["headers"]["x-api-key"], "test-key")

if __name__ == "__main__":
    unittest.main(verbosity=2)
