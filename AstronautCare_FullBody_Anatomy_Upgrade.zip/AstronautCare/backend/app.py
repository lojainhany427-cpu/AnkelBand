"""AstronautCare backend. Run: python app.py  ->  http://localhost:5000"""
import csv, io, json, math, os, queue, random, sqlite3, threading, time
from pathlib import Path
from flask import Flask, Response, jsonify, request, send_from_directory
from services.nasa import search_all
from services.ai import analyze_organ, organ_list, ai_status
from services.band_ai import analyze as analyze_band_demo, status as band_ai_status

ROOT = Path(__file__).resolve().parent
FRONTEND = ROOT.parent / "frontend"
DB_PATH = os.environ.get("ASTRONAUTCARE_DB", str(ROOT / "database" / "astronautcare.db"))
INGEST_TOKEN = os.environ.get("INGEST_TOKEN", "")
# Ranges come from the Wokwi main.py map_value() calls (see docs/sensor-mapping.md)
FIELDS = {"heartRate": (40, 160), "spo2": (85, 100), "temperature": (34, 40),
          "emg": (0, 100), "ankleAngle": (-90, 90), "footPressure": (0, 100)}
SOURCES = {"wokwi-simulation", "demo-generator", "real-hardware"}

app = Flask(__name__, static_folder=None)
LOCK = threading.Lock()
SUBS = []
STATE = {"latest": None, "demo": False}


def db():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    db_dir = os.path.dirname(os.path.abspath(DB_PATH))
    os.makedirs(db_dir, exist_ok=True)
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS readings(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, source TEXT NOT NULL,
            heartRate REAL, spo2 REAL, temperature REAL, emg REAL, ankleAngle REAL, footPressure REAL,
            fesEnabled INTEGER, redAlert INTEGER, alerts TEXT)""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_readings_ts ON readings(ts)")


def validate(p):
    if not isinstance(p, dict):
        raise ValueError("payload must be a JSON object")
    clean, warn = {}, []
    for k, (lo, hi) in FIELDS.items():
        v = p.get(k)
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
            clean[k] = None; warn.append(f"{k}: missing/invalid"); continue
        if not (lo - 1e-6 <= v <= hi + 1e-6):
            clean[k] = None; warn.append(f"{k}: {v} outside {lo}..{hi}"); continue
        clean[k] = float(v)
    clean["fesEnabled"] = p["fesEnabled"] if isinstance(p.get("fesEnabled"), bool) else None
    clean["redAlert"] = p["redAlert"] if isinstance(p.get("redAlert"), bool) else None
    a = p.get("alerts")
    clean["alerts"] = [x for x in a if isinstance(x, str)][:10] if isinstance(a, list) else []
    return clean, warn


def publish(clean, source, warnings):
    pkt = dict(clean, ts=time.time(), source=source, warnings=warnings)
    with db() as c:
        c.execute("INSERT INTO readings(ts,source,heartRate,spo2,temperature,emg,ankleAngle,footPressure,fesEnabled,redAlert,alerts) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                  (pkt["ts"], source, *(clean[k] for k in FIELDS),
                   None if clean["fesEnabled"] is None else int(clean["fesEnabled"]),
                   None if clean["redAlert"] is None else int(clean["redAlert"]), json.dumps(clean["alerts"])))
    with LOCK:
        STATE["latest"] = pkt
        for q in list(SUBS):
            try: q.put_nowait(snapshot())
            except queue.Full: pass
    return pkt


def snapshot():
    return {"latest": STATE["latest"], "serverTime": time.time(), "demo": STATE["demo"]}


@app.post("/api/ingest")
def ingest():
    if INGEST_TOKEN and request.headers.get("X-Ingest-Token") != INGEST_TOKEN:
        return jsonify(error="bad token"), 401
    body = request.get_json(silent=True)
    try:
        clean, warn = validate(body)
    except ValueError as e:
        return jsonify(error=str(e)), 400
    src = body.get("_source", "wokwi-simulation")
    if src not in SOURCES:
        return jsonify(error=f"_source must be one of {sorted(SOURCES)}"), 400
    return jsonify(ok=True, warnings=warn, ts=publish(clean, src, warn)["ts"])


@app.get("/api/stream")
def stream():
    q = queue.Queue(maxsize=50)
    with LOCK: SUBS.append(q)
    def gen():
        try:
            yield f"data: {json.dumps(snapshot())}\n\n"
            while True:
                try: item = q.get(timeout=2)
                except queue.Empty: item = snapshot()  # heartbeat -> client can detect stale data
                yield f"data: {json.dumps(item)}\n\n"
        finally:
            with LOCK:
                if q in SUBS: SUBS.remove(q)
    return Response(gen(), mimetype="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.get("/api/health")
def health():
    try:
        with db() as c:
            c.execute("SELECT 1").fetchone()
        db_ok = True
    except sqlite3.Error:
        db_ok = False
    return jsonify(ok=db_ok, service="AstronautCare", database=os.path.basename(DB_PATH), timestamp=time.time()), (200 if db_ok else 503)


@app.get("/api/latest")
def latest(): return jsonify(snapshot())


@app.get("/api/history")
def history():
    try:
        minutes = max(0.1, min(float(request.args.get("minutes", 5)), 1440))
        limit = max(1, min(int(request.args.get("limit", 600)), 5000))
    except (TypeError, ValueError):
        return jsonify(error="minutes and limit must be valid numbers"), 400
    with db() as c:
        rows = c.execute("SELECT * FROM readings WHERE ts>? ORDER BY ts DESC LIMIT ?", (time.time() - minutes * 60, limit)).fetchall()
    return jsonify([dict(r) for r in reversed(rows)])


@app.get("/api/export.csv")
def export_csv():
    try:
        minutes = max(0.1, min(float(request.args.get("minutes", 60)), 100000))
    except (TypeError, ValueError):
        return jsonify(error="minutes must be a valid number"), 400
    with db() as c:
        rows = c.execute("SELECT * FROM readings WHERE ts>? ORDER BY ts", (time.time() - minutes * 60,)).fetchall()
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["timestamp_utc", "data_source", *FIELDS, "fesEnabled", "redAlert", "alerts"])
    for r in rows:
        w.writerow([time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(r["ts"])), r["source"], *(r[k] for k in FIELDS), r["fesEnabled"], r["redAlert"], r["alerts"]])
    return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=astronautcare_report.csv"})


@app.post("/api/demo")
def demo():
    body = request.get_json(silent=True)
    if not isinstance(body, dict) or not isinstance(body.get("enabled"), bool):
        return jsonify(error="enabled must be a JSON boolean"), 400
    with LOCK:
        STATE["demo"] = body["enabled"]
        enabled = STATE["demo"]
    return jsonify(demo=enabled)


def demo_loop():
    t = 0
    while True:
        time.sleep(1)
        if not STATE["demo"]: continue
        t += 1
        s = lambda p, a, c: c + a * math.sin(t / p)
        clean, _ = validate({"heartRate": s(9, 15, 75), "spo2": s(17, 2, 97), "temperature": s(30, .3, 36.6),
                             "emg": max(0, s(4, 40, 45)), "ankleAngle": s(3, 30, 0), "footPressure": max(0, s(3, 40, 50) + random.uniform(-3, 3)),
                             "fesEnabled": False, "redAlert": False, "alerts": []})
        publish(clean, "demo-generator", ["demo data"])


@app.get("/api/services/status")
def services_status():
    return jsonify({"ai": ai_status(), "band_ai_demo": band_ai_status(),
                    "nasa": {"provider": "NASA NTRS + OSDR", "live_check": "Run a search from the Research page to test external access."},
                    "wokwi": {"bridge": "simulation/bridge.py", "live_check": "Requires a running Wokwi VS Code simulator with RFC2217 serial forwarding."}})


@app.get("/api/organs")
def organs(): return jsonify(organ_list())


@app.post("/api/analyze")
def analyze():
    oid = (request.get_json(silent=True) or {}).get("organ", "")
    try: return jsonify(analyze_organ(oid))
    except KeyError: return jsonify(error="unknown organ"), 404


@app.post("/api/band-ai-demo")
def band_ai_demo():
    """Run the archived model only on a complete synthetic feature vector."""
    body = request.get_json(silent=True)
    try:
        return jsonify(analyze_band_demo(body))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    except RuntimeError as exc:
        return jsonify(error=str(exc), available=False), 503


@app.get("/api/research")
def research():
    q = (request.args.get("q") or "").strip()
    if len(q) < 2: return jsonify(error="query too short"), 400
    result = search_all(q if "space" in q.lower() else q + " spaceflight")
    result["notice"] = ("No results returned. Check internet access or try another search." if not result["results"]
                        else "NASA records retrieved. Open each source link to review the original record.")
    return jsonify(result)


@app.get("/")
def index(): return send_from_directory(FRONTEND, "index.html")


@app.get("/<path:p>")
def static_files(p): return send_from_directory(FRONTEND, p)


init_db()
threading.Thread(target=demo_loop, daemon=True).start()

if __name__ == "__main__":
    # Local-only by default. Set HOST explicitly only for a trusted network deployment.
    app.run(host=os.environ.get("ASTRONAUTCARE_HOST", "127.0.0.1"),
            port=int(os.environ.get("ASTRONAUTCARE_PORT", "5000")), threaded=True)
