"""Local API tests. Run: python -m unittest test_app"""
import os
import tempfile
import unittest

# Use a temporary database before importing the Flask app.
_tmp = tempfile.TemporaryDirectory()
os.environ["ASTRONAUTCARE_DB"] = os.path.join(_tmp.name, "test.db")
from app import app, validate

class AstronautCareAPITests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_health(self):
        r = self.client.get("/api/health")
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.json["ok"])

    def test_ingest_rejects_non_object(self):
        r = self.client.post("/api/ingest", json=[1, 2, 3])
        self.assertEqual(r.status_code, 400)

    def test_ingest_accepts_valid_simulated_packet(self):
        packet = {"heartRate": 75, "spo2": 97, "temperature": 36.6,
                  "emg": 40, "ankleAngle": 12, "footPressure": 50,
                  "fesEnabled": False, "redAlert": False, "alerts": [],
                  "_source": "wokwi-simulation"}
        r = self.client.post("/api/ingest", json=packet)
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.json["ok"])

    def test_demo_requires_boolean(self):
        r = self.client.post("/api/demo", json={"enabled": "false"})
        self.assertEqual(r.status_code, 400)
        r = self.client.post("/api/demo", json={"enabled": False})
        self.assertEqual(r.status_code, 200)
        self.assertFalse(r.json["demo"])

    def test_invalid_sensor_value_becomes_missing_not_crash(self):
        clean, warnings = validate({"heartRate": "not-a-number", "ankleAngle": 10})
        self.assertIsNone(clean["heartRate"])
        self.assertIsNone(clean["spo2"])
        self.assertTrue(warnings)

    def test_history_bad_query_returns_400(self):
        r = self.client.get("/api/history?minutes=abc")
        self.assertEqual(r.status_code, 400)

if __name__ == "__main__":
    unittest.main()
