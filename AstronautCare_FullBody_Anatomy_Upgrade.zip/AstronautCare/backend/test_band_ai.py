"""Contract tests for the isolated synthetic classifier adapter."""
import unittest
from services.band_ai import FEATURES, analyze

class BandAIDemoContractTests(unittest.TestCase):
    def test_rejects_missing_features_instead_of_fabricating_them(self):
        with self.assertRaisesRegex(ValueError, "Missing required"):
            analyze({"hr": 70})

    def test_rejects_non_finite_and_boolean_values(self):
        payload = {k: 1 for k in FEATURES}
        payload["hr"] = True
        with self.assertRaisesRegex(ValueError, "finite number"):
            analyze(payload)

    def test_rejects_out_of_range_values(self):
        payload = {k: 1 for k in FEATURES}
        payload["spo2"] = 101
        with self.assertRaisesRegex(ValueError, "validation range"):
            analyze(payload)

if __name__ == "__main__":
    unittest.main()
